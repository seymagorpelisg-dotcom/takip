-- =====================================================================
-- İbadet Takip Defterim — veri tabanı şeması, erişim politikaları, RPC'ler
-- Supabase > SQL Editor'de TEK SEFERDE çalıştırın (yeni/boş proje için yazıldı).
-- Çalıştırdıktan sonra supabase/rls_tests.sql dosyasıyla erişim kurallarını sınayın.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. TABLOLAR
-- ---------------------------------------------------------------------

-- Kullanıcı profili. Rol YALNIZCA sunucu tarafında atanır (aşağıdaki tetikleyici + elle SQL).
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  role        text not null default 'student' check (role in ('student','teacher')),
  nickname    text not null check (char_length(nickname) between 2 and 30),
  created_at  timestamptz not null default now()
);

-- Sınıflar: bir öğretmene ait. join_code gizli tutulmalıdır (yalnızca öğretmen görür).
create table public.classes (
  id          uuid primary key default gen_random_uuid(),
  teacher_id  uuid not null references public.profiles(id) on delete cascade,
  name        text not null check (char_length(btrim(name)) between 1 and 60),
  join_code   text not null unique,
  join_open   boolean not null default true,
  created_at  timestamptz not null default now()
);
create index classes_teacher_idx on public.classes(teacher_id);

-- Sınıf üyeliği. Bir öğrenci aynı anda yalnızca bir sınıfta olabilir.
-- Kodla katılan öğrenci 'pending' başlar; öğretmen onaylayınca 'active' olur.
create table public.memberships (
  class_id    uuid not null references public.classes(id) on delete cascade,
  student_id  uuid not null unique references public.profiles(id) on delete cascade,
  status      text not null default 'pending' check (status in ('pending','active')),
  created_at  timestamptz not null default now(),
  primary key (class_id, student_id)
);
create index memberships_class_idx on public.memberships(class_id);

-- Günlük namaz kaydı. Gün başına tek satır (student_id, log_date).
-- NULL = "Henüz işaretlemedim", 'done' = Kıldım, 'missed' = Kılmadım.
create table public.daily_logs (
  student_id  uuid not null references public.profiles(id) on delete cascade,
  log_date    date not null,
  sabah       text check (sabah  in ('done','missed')),
  ogle        text check (ogle   in ('done','missed')),
  ikindi      text check (ikindi in ('done','missed')),
  aksam       text check (aksam  in ('done','missed')),
  yatsi       text check (yatsi  in ('done','missed')),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  primary key (student_id, log_date)
);

-- Kur'an okuma oturumları. Bir günde birden çok oturum olabilir.
-- id istemcide üretilir; aynı oturum tekrar gönderilirse (upsert) mükerrer kayıt oluşmaz.
create table public.quran_sessions (
  id          uuid primary key,
  student_id  uuid not null references public.profiles(id) on delete cascade,
  log_date    date not null,
  kind        text check (kind in ('tilavet','meal','ezber','diger')),
  start_ref   text check (char_length(start_ref) <= 60),
  start_page  integer check (start_page between 0 and 1000),
  end_ref     text check (char_length(end_ref) <= 60),
  end_page    integer check (end_page between 0 and 1000),
  minutes     integer check (minutes between 0 and 1440),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index quran_sessions_student_date_idx on public.quran_sessions(student_id, log_date);

-- Özel günlük not. ÖĞRETMEN HİÇBİR KOŞULDA OKUYAMAZ (aşağıda yalnızca sahibine politika var).
create table public.private_notes (
  student_id  uuid not null references public.profiles(id) on delete cascade,
  log_date    date not null,
  note        text not null check (char_length(note) between 1 and 500),
  updated_at  timestamptz not null default now(),
  primary key (student_id, log_date)
);

-- ---------------------------------------------------------------------
-- 2. TETİKLEYİCİLER
-- ---------------------------------------------------------------------

-- Yeni kullanıcı => her zaman 'student'. Öğretmen rolü elle atanır (README, Bölüm 4).
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_nick text;
begin
  v_nick := coalesce(nullif(btrim(left(coalesce(new.raw_user_meta_data->>'nickname',''), 30)), ''),
                     split_part(new.email, '@', 1));
  if char_length(v_nick) < 2 then v_nick := 'Kullanıcı'; end if;
  insert into public.profiles (id, role, nickname) values (new.id, 'student', v_nick);
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

create function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

create trigger daily_logs_touch    before update on public.daily_logs    for each row execute function public.touch_updated_at();
create trigger quran_sessions_touch before update on public.quran_sessions for each row execute function public.touch_updated_at();
create trigger private_notes_touch before update on public.private_notes for each row execute function public.touch_updated_at();

-- Gelecek güne kayıt girilemez (Türkiye saati).
create function public.enforce_log_date() returns trigger language plpgsql as $$
begin
  if new.log_date > (now() at time zone 'Europe/Istanbul')::date then
    raise exception 'Gelecekteki bir güne kayıt girilemez' using errcode = '22008';
  end if;
  return new;
end $$;

create trigger daily_logs_date    before insert or update of log_date on public.daily_logs    for each row execute function public.enforce_log_date();
create trigger quran_sessions_date before insert or update of log_date on public.quran_sessions for each row execute function public.enforce_log_date();
create trigger private_notes_date before insert or update of log_date on public.private_notes for each row execute function public.enforce_log_date();

-- Kötüye kullanım sınırı: bir günde en fazla 20 Kur'an oturumu.
create function public.limit_sessions_per_day() returns trigger language plpgsql as $$
begin
  if (select count(*) from public.quran_sessions
        where student_id = new.student_id and log_date = new.log_date and id <> new.id) >= 20 then
    raise exception 'Bir günde en fazla 20 Kur''an oturumu kaydedilebilir' using errcode = '54000';
  end if;
  return new;
end $$;

create trigger quran_sessions_limit before insert or update of log_date on public.quran_sessions
  for each row execute function public.limit_sessions_per_day();

-- ---------------------------------------------------------------------
-- 3. YARDIMCI FONKSİYONLAR (RLS özyinelemesini önlemek için SECURITY DEFINER)
-- ---------------------------------------------------------------------

create function public.is_teacher() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'teacher')
$$;

create function public.teacher_owns_class(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_teacher()
     and exists (select 1 from public.classes where id = cid and teacher_id = auth.uid())
$$;

-- Öğretmen, ONAYLANMIŞ (active) öğrencinin kayıtlarını görebilir.
create function public.teacher_sees_student(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_teacher() and exists (
    select 1 from public.memberships m join public.classes c on c.id = m.class_id
    where m.student_id = sid and m.status = 'active' and c.teacher_id = auth.uid())
$$;

-- Öğretmen, onay bekleyen öğrencinin YALNIZCA rumuzunu (profil) görebilir.
create function public.teacher_knows_student(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_teacher() and exists (
    select 1 from public.memberships m join public.classes c on c.id = m.class_id
    where m.student_id = sid and c.teacher_id = auth.uid())
$$;

-- ---------------------------------------------------------------------
-- 4. YETKİLER (GRANT) — varsayılanı kapat, gerekeni aç
-- ---------------------------------------------------------------------
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon;
alter default privileges in schema public revoke all on tables    from anon;
alter default privileges in schema public revoke all on functions from anon;

grant select                              on public.profiles       to authenticated;
grant update (nickname)                   on public.profiles       to authenticated;  -- rol DEĞİŞTİRİLEMEZ
grant select, delete                      on public.classes        to authenticated;
grant update (name, join_open)            on public.classes        to authenticated;
grant select, delete                      on public.memberships    to authenticated;
grant update (status)                     on public.memberships    to authenticated;
grant select, insert, update, delete      on public.daily_logs     to authenticated;
grant select, insert, update, delete      on public.quran_sessions to authenticated;
grant select, insert, update, delete      on public.private_notes  to authenticated;

grant execute on function public.is_teacher()                 to authenticated;
grant execute on function public.teacher_owns_class(uuid)     to authenticated;
grant execute on function public.teacher_sees_student(uuid)   to authenticated;
grant execute on function public.teacher_knows_student(uuid)  to authenticated;

-- ---------------------------------------------------------------------
-- 5. ROW LEVEL SECURITY
-- ---------------------------------------------------------------------
alter table public.profiles       enable row level security;
alter table public.classes        enable row level security;
alter table public.memberships    enable row level security;
alter table public.daily_logs     enable row level security;
alter table public.quran_sessions enable row level security;
alter table public.private_notes  enable row level security;

-- profiles
create policy profiles_select_own     on public.profiles for select to authenticated using (id = auth.uid());
create policy profiles_select_teacher on public.profiles for select to authenticated using (public.teacher_knows_student(id));
create policy profiles_update_own     on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- classes (öğrenciler sınıf tablosunu OKUYAMAZ; kendi üyeliklerini my_membership() ile görürler)
create policy classes_select_owner on public.classes for select to authenticated using (public.teacher_owns_class(id));
create policy classes_update_owner on public.classes for update to authenticated using (public.teacher_owns_class(id)) with check (public.teacher_owns_class(id));
create policy classes_delete_owner on public.classes for delete to authenticated using (public.teacher_owns_class(id));

-- memberships (ekleme yalnızca join_class() ile; 'status' güncellemesi yalnızca sınıfın öğretmenine açık, öğrenci kendini onaylayamaz)
create policy memberships_select on public.memberships for select to authenticated
  using (student_id = auth.uid() or public.teacher_owns_class(class_id));
create policy memberships_update_teacher on public.memberships for update to authenticated
  using (public.teacher_owns_class(class_id)) with check (public.teacher_owns_class(class_id));
create policy memberships_delete on public.memberships for delete to authenticated
  using (student_id = auth.uid() or public.teacher_owns_class(class_id));

-- daily_logs
create policy logs_owner   on public.daily_logs for all    to authenticated using (student_id = auth.uid()) with check (student_id = auth.uid());
create policy logs_teacher on public.daily_logs for select to authenticated using (public.teacher_sees_student(student_id));

-- quran_sessions
create policy sessions_owner   on public.quran_sessions for all    to authenticated using (student_id = auth.uid()) with check (student_id = auth.uid());
create policy sessions_teacher on public.quran_sessions for select to authenticated using (public.teacher_sees_student(student_id));

-- private_notes: yalnızca sahibi
create policy notes_owner on public.private_notes for all to authenticated using (student_id = auth.uid()) with check (student_id = auth.uid());

-- ---------------------------------------------------------------------
-- 6. RPC FONKSİYONLARI (yetki kontrolü fonksiyonun İÇİNDE yapılır)
-- ---------------------------------------------------------------------

-- Öğretmen: sınıf oluştur. Katılım kodu sunucuda rastgele üretilir (10 hane).
create function public.create_class(p_name text)
returns table (out_id uuid, out_join_code text)
language plpgsql security definer set search_path = public as $$
declare v_code text; v_id uuid; v_try int := 0;
begin
  if not public.is_teacher() then raise exception 'Yalnızca öğretmenler sınıf oluşturabilir' using errcode = '42501'; end if;
  if char_length(btrim(coalesce(p_name,''))) not between 1 and 60 then raise exception 'Sınıf adı 1-60 karakter olmalı'; end if;
  loop
    v_code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10));
    exit when not exists (select 1 from public.classes where join_code = v_code);
    v_try := v_try + 1; if v_try > 10 then raise exception 'Kod üretilemedi'; end if;
  end loop;
  insert into public.classes (teacher_id, name, join_code) values (auth.uid(), btrim(p_name), v_code) returning id into v_id;
  return query select v_id, v_code;
end $$;

-- Öğretmen: katılım kodunu yenile (eski kod geçersiz olur).
create function public.regenerate_join_code(p_class_id uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  if not public.teacher_owns_class(p_class_id) then raise exception 'Bu sınıf üzerinde yetkiniz yok' using errcode = '42501'; end if;
  loop
    v_code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10));
    exit when not exists (select 1 from public.classes where join_code = v_code);
  end loop;
  update public.classes set join_code = v_code where id = p_class_id;
  return v_code;
end $$;

-- Öğrenci: kodla sınıfa KATILMA İSTEĞİ gönder. Yalnızca KENDİ hesabı için, 'pending' olarak.
create function public.join_class(p_code text)
returns table (out_class_name text, out_status text)
language plpgsql security definer set search_path = public as $$
declare c public.classes%rowtype;
begin
  if auth.uid() is null then raise exception 'Giriş gerekli' using errcode = '28000'; end if;
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'student') then
    raise exception 'Yalnızca öğrenci hesapları sınıfa katılabilir' using errcode = '42501';
  end if;
  select * into c from public.classes where join_code = upper(btrim(coalesce(p_code,''))) and join_open;
  if not found then raise exception 'Sınıf kodu geçersiz veya katılıma kapalı'; end if;
  if exists (select 1 from public.memberships where student_id = auth.uid()) then
    raise exception 'Zaten bir sınıfa bağlısın. Önce sınıftan ayrılmalısın';
  end if;
  insert into public.memberships (class_id, student_id, status) values (c.id, auth.uid(), 'pending');
  return query select c.name, 'pending'::text;
end $$;

-- Öğrenci: kendi üyelik durumu (sınıf tablosunu okumadan).
create function public.my_membership()
returns table (out_class_name text, out_status text)
language sql stable security definer set search_path = public as $$
  select c.name, m.status from public.memberships m join public.classes c on c.id = m.class_id
  where m.student_id = auth.uid()
$$;

-- Öğrenci: kendi tüm kayıtlarını ve üyeliğini sil. (Auth hesabının kendisi README'deki yönergeyle silinir.)
create function public.delete_my_data() returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Giriş gerekli' using errcode = '28000'; end if;
  delete from public.quran_sessions where student_id = auth.uid();
  delete from public.daily_logs     where student_id = auth.uid();
  delete from public.private_notes  where student_id = auth.uid();
  delete from public.memberships    where student_id = auth.uid();
end $$;

revoke all on function public.create_class(text)           from public, anon;
revoke all on function public.regenerate_join_code(uuid)   from public, anon;
revoke all on function public.join_class(text)             from public, anon;
revoke all on function public.my_membership()              from public, anon;
revoke all on function public.delete_my_data()             from public, anon;
grant execute on function public.create_class(text)         to authenticated;
grant execute on function public.regenerate_join_code(uuid) to authenticated;
grant execute on function public.join_class(text)           to authenticated;
grant execute on function public.my_membership()            to authenticated;
grant execute on function public.delete_my_data()           to authenticated;

-- ---------------------------------------------------------------------
-- 7. GERÇEK ZAMANLI YAYIN (Realtime). Olaylar RLS'ye tabidir; arayüz yine de
--    olay yükünü kullanmaz, değişiklikte verileri yetkili sorgularla yeniden çeker.
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['daily_logs','quran_sessions','memberships'] loop
    if not exists (select 1 from pg_publication_tables
                   where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end $$;
