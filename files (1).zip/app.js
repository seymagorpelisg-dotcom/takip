/* İbadet Takip Defterim — Supabase tabanlı çevrim içi uygulama
 * Güvenlik: Tüm yetkilendirme veri tabanındaki RLS kurallarıyla yapılır (supabase/schema.sql).
 * Bu dosyadaki rol kontrolleri yalnızca arayüzü yönlendirir; güvenlik önlemi değildir.
 */
'use strict';
(function () {
  const CFG = window.IBADET_CONFIG || {};
  const app = document.getElementById('app');
  const toastEl = document.getElementById('toast');

  /* ---------- Sabitler ---------- */
  const PRAYERS = ['Sabah', 'Öğle', 'İkindi', 'Akşam', 'Yatsı'];
  const PKEYS = ['sabah', 'ogle', 'ikindi', 'aksam', 'yatsi'];
  const DOW = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
  const MONTHS = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  const KINDS = { tilavet: 'Arapça tilavet', meal: 'Meal okuma', ezber: 'Ezber tekrarı', diger: 'Diğer' };
  const SURAHS = ['Fâtiha', 'Bakara', 'Âl-i İmrân', 'Nisâ', 'Mâide', 'En’âm', 'A’râf', 'Enfâl', 'Tevbe', 'Yûnus', 'Hûd', 'Yûsuf', 'Ra’d', 'İbrâhîm', 'Hicr', 'Nahl', 'İsrâ', 'Kehf', 'Meryem', 'Tâhâ', 'Enbiyâ', 'Hac', 'Mü’minûn', 'Nûr', 'Furkân', 'Şuarâ', 'Neml', 'Kasas', 'Ankebût', 'Rûm', 'Lokmân', 'Secde', 'Ahzâb', 'Sebe’', 'Fâtır', 'Yâsîn', 'Sâffât', 'Sâd', 'Zümer', 'Mü’min', 'Fussilet', 'Şûrâ', 'Zuhruf', 'Duhân', 'Câsiye', 'Ahkâf', 'Muhammed', 'Fetih', 'Hucurât', 'Kâf', 'Zâriyât', 'Tûr', 'Necm', 'Kamer', 'Rahmân', 'Vâkıa', 'Hadîd', 'Mücâdele', 'Haşr', 'Mümtehine', 'Saff', 'Cuma', 'Münâfikûn', 'Teğâbün', 'Talâk', 'Tahrîm', 'Mülk', 'Kalem', 'Hâkka', 'Meâric', 'Nûh', 'Cin', 'Müzzemmil', 'Müddessir', 'Kıyâme', 'İnsân', 'Mürselât', 'Nebe’', 'Nâziât', 'Abese', 'Tekvîr', 'İnfitâr', 'Mutaffifîn', 'İnşikâk', 'Bürûc', 'Târık', 'A’lâ', 'Gâşiye', 'Fecr', 'Beled', 'Şems', 'Leyl', 'Duhâ', 'İnşirâh', 'Tîn', 'Alak', 'Kadir', 'Beyyine', 'Zilzâl', 'Âdiyât', 'Kâria', 'Tekâsür', 'Asr', 'Hümeze', 'Fîl', 'Kureyş', 'Mâûn', 'Kevser', 'Kâfirûn', 'Nasr', 'Tebbet', 'İhlâs', 'Felak', 'Nâs'];
  const BACKUP_APP = 'ibadet-takip-defterim';

  /* ---------- Yardımcılar ---------- */
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d, 12); };
  const addDays = (s, n) => { const d = parse(s); d.setDate(d.getDate() + n); return ymd(d); };
  const todayS = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'Europe/Istanbul' }); // Türkiye saatine göre bugün
  const weekStart = s => { const d = parse(s); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return ymd(d); };
  const monthStart = s => s.slice(0, 8) + '01';
  const addMonths = (s, n) => { const d = parse(s); d.setDate(1); d.setMonth(d.getMonth() + n); return ymd(d); };
  const daysInMonth = s => { const d = parse(s); return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); };
  const isDate = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && ymd(parse(s)) === s;
  const spanDays = (a, b) => Math.round((parse(b) - parse(a)) / 86400000) + 1;
  function daysBetween(a, b) { const out = []; let c = a, g = 0; while (c <= b && g++ < 800) { out.push(c); c = addDays(c, 1); } return out; }
  const weekDates = s => daysBetween(s, addDays(s, 6));
  const monthDates = ms => daysBetween(ms, addDays(ms, daysInMonth(ms) - 1));
  const fmtLong = s => parse(s).toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const fmtShort = s => parse(s).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' });
  function rangeLabel(a, b) { return fmtShort(a) + (a.slice(0, 4) !== b.slice(0, 4) ? ' ' + a.slice(0, 4) : '') + ' – ' + fmtShort(b) + ' ' + b.slice(0, 4); }
  const monthLabel = s => MONTHS[parse(s).getMonth()] + ' ' + parse(s).getFullYear();
  const trSort = (a, b) => String(a).localeCompare(String(b), 'tr');
  const fmtTime = d => d ? d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '–';
  const fmtStamp = iso => iso ? new Date(iso).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '–';
  function uuid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    const b = crypto.getRandomValues(new Uint8Array(16)); b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128;
    const h = [...b].map(x => x.toString(16).padStart(2, '0')).join('');
    return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
  }
  function slug(s) {
    const map = { 'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u' };
    return String(s).toLocaleLowerCase('tr-TR').replace(/[çğıöşü]/g, c => map[c]).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'dosya';
  }
  let toastTimer;
  function toast(msg) { toastEl.textContent = msg; toastEl.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toastEl.classList.remove('show'), 3000); }
  function download(name, text, type) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: type || 'application/json' })); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  async function copyText(text) {
    try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); return true; } } catch (e) { /* düş */ }
    const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; } ta.remove(); return ok;
  }
  const csvCell = v => { let s = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
  const isNetErr = e => !navigator.onLine || /failed to fetch|network|load failed|fetch/i.test(String((e && e.message) || e));
  function errText(e) {
    const m = String((e && e.message) || e || '');
    if (isNetErr(e)) return 'İnternet bağlantısı yok veya sunucuya ulaşılamıyor.';
    return m || 'Bilinmeyen hata.';
  }

  /* ---------- Yapılandırma denetimi ---------- */
  const configured = !!(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY && !/BURAYA/.test(CFG.SUPABASE_URL + CFG.SUPABASE_ANON_KEY));
  if (!configured || !window.supabase) {
    app.innerHTML = `<main id="main"><section class="card" style="max-width:640px;margin:2rem auto"><h1>İbadet Takip Defterim</h1>
      <p class="err" style="margin-top:1rem">Uygulama henüz yapılandırılmamış.</p>
      <p>${!window.supabase ? 'Supabase kütüphanesi yüklenemedi (internet bağlantısını veya içerik engelleyicileri kontrol edin).' : '<code>web/config.js</code> dosyasındaki <code>SUPABASE_URL</code> ve <code>SUPABASE_ANON_KEY</code> değerlerini kendi Supabase projenizinkilerle değiştirin. Adımlar için README.md dosyasına bakın.'}</p></section></main>`;
    return;
  }
  const sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true } });
  const toEmail = r => r + '@' + (CFG.STUDENT_EMAIL_DOMAIN || 'ogrenci.invalid');

  async function fetchAll(make) {
    const out = [];
    for (let from = 0; ; from += 1000) {
      const { data, error } = await make().range(from, from + 999);
      if (error) throw error;
      out.push(...data);
      if (data.length < 1000) break;
    }
    return out;
  }

  /* ---------- Ortak veri modeli ---------- */
  // info = { p:[5 durum|null], sess:[oturumlar], has:boolean }
  function mkInfo(log, sess) {
    const p = PKEYS.map(k => (log && log[k]) || null);
    sess = sess || [];
    return { p, sess, has: p.some(Boolean) || sess.length > 0 };
  }
  function statsFor(dates, getInfo) {
    const t = todayS();
    const s = { days: 0, possible: 0, done: 0, missed: 0, unmarked: 0, recDays: 0, qDays: 0, sessions: 0, minutes: 0 };
    dates.forEach(d => {
      if (d > t) return;
      const i = getInfo(d);
      s.days++; s.possible += 5;
      i.p.forEach(v => { if (v === 'done') s.done++; else if (v === 'missed') s.missed++; });
      if (i.has) s.recDays++;
      if (i.sess.length) { s.qDays++; s.sessions += i.sess.length; i.sess.forEach(x => { s.minutes += x.minutes || 0; }); }
    });
    s.unmarked = s.possible - s.done - s.missed;
    return s;
  }
  const markHTML = v => v === 'done' ? '<span class="m done" role="img" aria-label="Kıldım">✓</span>' : v === 'missed' ? '<span class="m missed" role="img" aria-label="Kılmadım">✕</span>' : '<span class="m none" role="img" aria-label="Henüz işaretlenmedi">○</span>';

  function gridHTML(start, getInfo, o) {
    o = o || {};
    const t = todayS(), days = weekDates(start);
    let h = `<div class="gridwrap"><table class="grid"><caption class="sr-only">${esc(o.caption || 'Haftalık çizelge')}</caption><thead><tr><th scope="col"><span class="sr-only">Vakit</span></th>`;
    days.forEach((d, i) => {
      const head = `<span class="dw">${DOW[i]}</span><span class="dn">${parse(d).getDate()}</span>`;
      h += `<th scope="col" class="${d === t ? 'today' : ''}">${o.link ? `<button class="dayhead" data-act="goto-day" data-date="${d}" aria-label="${esc(fmtLong(d))} gününe git">${head}</button>` : head}</th>`;
    });
    h += '</tr></thead><tbody>';
    PRAYERS.forEach((nm, i) => {
      h += `<tr><th scope="row">${nm}</th>`;
      days.forEach(d => { const x = d > t ? undefined : getInfo(d); h += d > t ? '<td class="future"></td>' : !x ? '<td class="na" title="Seçili dönemin dışında">–</td>' : `<td>${markHTML(x.p[i])}</td>`; });
      h += '</tr>';
    });
    h += '<tr><th scope="row">Kur’an</th>';
    days.forEach(d => {
      if (d > t) { h += '<td class="future"></td>'; return; }
      if (!getInfo(d)) { h += '<td class="na" title="Seçili dönemin dışında">–</td>'; return; }
      const s = getInfo(d).sess, min = s.reduce((a, x) => a + (x.minutes || 0), 0);
      h += s.length ? `<td><span class="m q" role="img" aria-label="${s.length} oturum">${s.length}</span>${min ? `<small>${min} dk</small>` : ''}</td>` : '<td><span class="m none" role="img" aria-label="Kur’an kaydı yok">–</span></td>';
    });
    return h + '</tr></tbody></table></div>';
  }
  const legendHTML = outside => `<div class="legend"><span><span class="m done">✓</span>Kıldım</span><span><span class="m missed">✕</span>Kılmadım</span><span><span class="m none">○</span>Henüz işaretlenmedi</span><span><span class="m q">2</span>Kur’an oturumu sayısı</span>${outside ? '<span><i class="hatch"></i>– seçili dönemin dışında</span>' : ''}</div>`;

  function monthHTML(ms, getInfo, link) {
    const t = todayS();
    let h = '<div class="cal-head" aria-hidden="true">' + DOW.map(x => `<div>${x}</div>`).join('') + '</div><div class="cal-grid">';
    for (let i = 0; i < (parse(ms).getDay() + 6) % 7; i++) h += '<div class="cal empty"></div>';
    monthDates(ms).forEach(d => {
      const fut = d > t, i0 = fut ? null : getInfo(d);
      if (!fut && !i0) { h += `<div class="cal na" role="group" aria-label="${esc(fmtShort(d))}: seçili dönemin dışında"><span class="cn">${parse(d).getDate()}</span><span aria-hidden="true">–</span></div>`; return; }
      const i = i0 || mkInfo(null, []), done = i.p.filter(v => v === 'done').length, miss = i.p.filter(v => v === 'missed').length;
      const cls = 'cal' + (d === t ? ' today' : '') + (fut ? ' future' : '');
      const txt = fut ? '' : (i.p.some(Boolean) ? `${done}✓${miss ? ' ' + miss + '✕' : ''}` : '○') + (i.sess.length ? ' K' + i.sess.length : '');
      const label = fut ? fmtShort(d) : `${fmtShort(d)}: ${done} kıldım, ${miss} kılmadım, ${5 - done - miss} işaretlenmedi${i.sess.length ? ', ' + i.sess.length + ' Kur’an oturumu' : ''}`;
      const inner = `<span class="cn">${parse(d).getDate()}</span><span>${txt}</span>`;
      h += link ? `<button class="${cls}" data-act="goto-day" data-date="${d}" aria-label="${esc(label)}"${fut ? ' disabled' : ''}>${inner}</button>` : `<div class="${cls}" role="group" aria-label="${esc(label)}">${inner}</div>`;
    });
    return h + '</div>';
  }
  function factsHTML(s, note) {
    if (!s.days) return '<p class="hint">Bu dönem için gösterilecek gün yok.</p>';
    return `<ul class="facts">
      <li><span>Kıldım olarak işaretlenen</span><strong>${s.done}</strong></li>
      <li><span>Kılmadım olarak işaretlenen</span><strong>${s.missed}</strong></li>
      <li><span>Henüz işaretlenmemiş</span><strong>${s.unmarked}</strong></li>
      <li><span>Kayıt girilen gün</span><strong>${s.recDays} / ${s.days}</strong></li>
      <li><span>Kur’an okunan gün</span><strong>${s.qDays}</strong></li>
      <li><span>Kur’an oturumu · toplam süre</span><strong>${s.sessions} · ${s.minutes} dk</strong></li></ul>
      ${note === false ? '' : `<p class="hint">Hesaba yalnızca bugüne kadarki günler katılır (${s.days} gün × 5 vakit = ${s.possible}). İşaretlenmemiş bir vakit “kılınmadı” sayılmaz; yalnızca “henüz işaretlenmedi” olarak gösterilir.</p>`}`;
  }

  /* ---------- Genel durum ---------- */
  const A = { screen: 'loading', user: null, profile: null, authTab: 'student', authMsg: '', busy: false, fatal: '', form: { id: '', code: '' } };
  let S = null; // öğrenci durumu
  let T = null; // öğretmen durumu

  const Q = { pending: new Map(), failed: new Map(), flushing: false, save: 'idle', lastSaved: null, lastError: '' };

  /* ---------- Giriş / çıkış ---------- */
  async function boot() {
    try {
      const { data, error } = await sb.auth.getSession();
      if (error) throw error;
      if (data.session) { A.user = data.session.user; await enterApp(); } else { A.screen = 'auth'; render(); }
    } catch (e) { A.screen = 'fatal'; A.fatal = errText(e); render(); }
    sb.auth.onAuthStateChange((ev) => { if (ev === 'SIGNED_OUT' && A.user) setTimeout(() => { if (A.user) resetToAuth(); }, 0); });
  }
  async function enterApp() {
    A.screen = 'loading'; render();
    const { data, error } = await sb.from('profiles').select('id,role,nickname').eq('id', A.user.id).maybeSingle();
    if (error) throw error;
    if (!data) { A.screen = 'fatal'; A.fatal = 'Profil bulunamadı. Veri tabanı kurulumunu (schema.sql) kontrol edin.'; render(); return; }
    A.profile = data;
    if (data.role === 'teacher') await initTeacher(); else await initStudent();
  }
  function resetToAuth() {
    tTeardown(); A.user = null; A.profile = null; S = null; T = null; Q.pending.clear(); Q.failed.clear(); Q.save = 'idle';
    A.screen = 'auth'; A.authMsg = ''; render(true);
  }
  async function signOut() {
    if (S) commitNote();
    if (Q.pending.size && !confirm('Henüz sunucuya kaydedilmemiş değişiklikler var. Çıkarsan bu değişiklikler kaybolur. Çıkılsın mı?')) return;
    await sb.auth.signOut();
    if (A.user) resetToAuth();
  }
  function authError(e) {
    const m = String((e && e.message) || e);
    if (isNetErr(e)) return 'İnternet bağlantısı yok veya sunucuya ulaşılamıyor.';
    if (/invalid login/i.test(m)) return 'Rumuz/e-posta veya şifre yanlış.';
    if (/already registered|already been registered/i.test(m)) return 'Bu rumuz alınmış. Başka bir rumuz dene (örn. sonuna rakam ekle).';
    if (/password/i.test(m) && /6|short|least/i.test(m)) return 'Şifre en az 6 karakter olmalı.';
    if (/rate limit|too many/i.test(m)) return 'Çok fazla deneme yapıldı. Biraz bekleyip tekrar dene.';
    if (/email.*(invalid|not allowed)|invalid.*email/i.test(m)) return 'Hesap oluşturulamadı: sunucu, rumuzdan üretilen e-posta adresini kabul etmedi. Öğretmeninden yöneticiye bildirmesini iste (README, Bölüm 3).';
    return m;
  }
  async function doLogin(kind) {
    const idv = document.getElementById('aId').value.trim(), pw = document.getElementById('aPw').value;
    if (!idv || !pw) { A.authMsg = 'Lütfen bilgileri doldur.'; render(); return; }
    const email = kind === 'teacher' ? idv.toLowerCase() : toEmail(idv.toLowerCase());
    A.busy = true; A.authMsg = ''; render();
    try {
      const { data, error } = await sb.auth.signInWithPassword({ email, password: pw });
      if (error) throw error;
      A.user = data.user; A.busy = false; A.form = { id: '', code: '' };
      await enterApp();
      if (kind === 'teacher' && A.profile && A.profile.role !== 'teacher') {
        await sb.auth.signOut(); resetToAuth(); A.authMsg = 'Bu hesap bir öğretmen hesabı değil.'; render();
      }
    } catch (e) { A.busy = false; A.screen = 'auth'; A.authMsg = authError(e); render(); }
  }
  async function doSignup() {
    const rumuz = document.getElementById('aId').value.trim().toLowerCase(), pw = document.getElementById('aPw').value, code = document.getElementById('aCode').value.trim();
    if (!/^[a-z0-9_]{3,20}$/.test(rumuz)) { A.authMsg = 'Rumuz 3-20 karakter olmalı; yalnızca küçük harf (a-z), rakam ve alt çizgi kullan.'; render(); return; }
    if (pw.length < 6) { A.authMsg = 'Şifre en az 6 karakter olmalı.'; render(); return; }
    if (!code) { A.authMsg = 'Öğretmeninin verdiği sınıf kodunu yaz.'; render(); return; }
    A.busy = true; A.authMsg = ''; render();
    try {
      const { data, error } = await sb.auth.signUp({ email: toEmail(rumuz), password: pw, options: { data: { nickname: rumuz } } });
      if (error) throw error;
      if (!data.session) throw new Error('Hesap oluştu ancak oturum açılamadı. Supabase projesinde “Confirm email” ayarı KAPALI olmalı (README, Bölüm 3).');
      A.user = data.user; A.busy = false;
      const j = await sb.rpc('join_class', { p_code: code });
      await enterApp();
      if (j.error && S) { S.joinMsg = 'Hesabın oluşturuldu ama sınıfa katılamadın: ' + j.error.message; render(); }
    } catch (e) { A.busy = false; if (!A.user) { A.screen = 'auth'; A.authMsg = authError(e); render(); } else { toast(errText(e)); } }
  }

  /* =====================================================================
   *  ÖĞRENCİ
   * ===================================================================== */
  async function initStudent() {
    const uid = A.user.id;
    S = { tab: 'bugun', date: todayS(), wk: weekStart(todayS()), mon: monthStart(todayS()), logs: {}, sess: {}, notes: {}, member: null, form: null, joinMsg: '', loadErr: '' };
    try {
      const [logs, sess, notes, mem] = await Promise.all([
        fetchAll(() => sb.from('daily_logs').select('*').eq('student_id', uid).order('log_date')),
        fetchAll(() => sb.from('quran_sessions').select('*').eq('student_id', uid).order('id')),
        fetchAll(() => sb.from('private_notes').select('log_date,note').eq('student_id', uid).order('log_date')),
        sb.rpc('my_membership')
      ]);
      logs.forEach(r => { S.logs[r.log_date] = r; });
      sess.forEach(r => { S.sess[r.id] = r; });
      notes.forEach(r => { S.notes[r.log_date] = r.note; });
      if (mem.error) throw mem.error;
      S.member = (mem.data && mem.data[0]) || null;
      Q.save = 'loaded';
    } catch (e) { S.loadErr = errText(e); }
    A.screen = 'student'; render(true);
  }
  const sessOn = d => Object.values(S.sess).filter(x => x.log_date === d).sort((a, b) => String(a.created_at || a._ts || '').localeCompare(String(b.created_at || b._ts || '')));
  const infoS = d => mkInfo(S.logs[d], sessOn(d));

  /* Kayıt kuyruğu: durumdan türetilir (idempotent). Sunucu onayı gelmeden "Kaydedildi" denmez. */
  function markDirty(key) { Q.pending.set(key, (Q.pending.get(key) || 0) + 1); Q.failed.delete(key); flush(); }
  async function sendOp(key) {
    const i = key.indexOf(':'), type = key.slice(0, i), id = key.slice(i + 1), uid = A.user.id;
    let res;
    if (type === 'log') {
      const l = S.logs[id] || {}, row = { student_id: uid, log_date: id };
      PKEYS.forEach(k => { row[k] = l[k] || null; });
      res = await sb.from('daily_logs').upsert(row, { onConflict: 'student_id,log_date' });
    } else if (type === 'sess') {
      const x = S.sess[id];
      if (x) res = await sb.from('quran_sessions').upsert({ id, student_id: uid, log_date: x.log_date, kind: x.kind || null, start_ref: x.start_ref || null, start_page: x.start_page == null ? null : x.start_page, end_ref: x.end_ref || null, end_page: x.end_page == null ? null : x.end_page, minutes: x.minutes == null ? null : x.minutes }, { onConflict: 'id' });
      else res = await sb.from('quran_sessions').delete().eq('id', id);
    } else if (type === 'note') {
      const n = (S.notes[id] || '').trim();
      if (n) res = await sb.from('private_notes').upsert({ student_id: uid, log_date: id, note: n.slice(0, 500) }, { onConflict: 'student_id,log_date' });
      else res = await sb.from('private_notes').delete().eq('student_id', uid).eq('log_date', id);
    }
    if (res && res.error) throw res.error;
  }
  async function flush() {
    if (Q.flushing) return;
    Q.flushing = true; setSave('saving');
    let net = false;
    try {
      let progress = true;
      while (progress && Q.pending.size && !net) {
        progress = false;
        for (const [key, ver] of [...Q.pending]) {
          if (Q.failed.has(key)) continue;
          try { await sendOp(key); if (Q.pending.get(key) === ver) Q.pending.delete(key); progress = true; }
          catch (e) { if (isNetErr(e)) { net = true; break; } Q.failed.set(key, errText(e)); Q.lastError = errText(e); }
        }
      }
    } finally { Q.flushing = false; }
    if (net) setSave('offline');
    else if (Q.failed.size) setSave('error');
    else { Q.lastSaved = new Date(); setSave('saved'); }
  }
  function setSave(s) { Q.save = s; const el = document.getElementById('saveChip'); if (el) el.outerHTML = saveChipHTML(); const w = document.getElementById('unsyncedNote'); if (w) w.outerHTML = unsyncedHTML(); }
  function saveChipHTML() {
    const m = { idle: ['', ''], loaded: ['', '✓ Sunucudan yüklendi'], saving: ['', '⟳ Kaydediliyor…'], saved: ['', '✓ Kaydedildi' + (Q.lastSaved ? ' (' + Q.lastSaved.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) + ')' : '')], offline: ['bad', '⚠ İnternet yok: değişiklikler sunucuya GÖNDERİLMEDİ'], error: ['bad', '✕ Kaydedilemedi'] }[Q.save] || ['', ''];
    return `<span id="saveChip" class="status ${m[0]}" role="status">${m[1]}</span>` + (Q.save === 'offline' || Q.save === 'error' ? ' <button class="btn ghost small" data-act="retry-save">Tekrar dene</button>' : '');
  }
  function unsyncedHTML() {
    if (!S) return '<div id="unsyncedNote"></div>';
    const d = S.date, dirty = [...Q.pending.keys()].some(k => k.endsWith(':' + d) || (k.startsWith('sess:') && S.sess[k.slice(5)] && S.sess[k.slice(5)].log_date === d));
    return `<div id="unsyncedNote">${dirty ? '<p class="err small" style="margin-top:.5rem" role="status">Bu günün değişiklikleri henüz sunucuya kaydedilmedi. Bu cihazdaki görüntü, sunucudaki kayıtla aynı değildir.</p>' : ''}</div>`;
  }
  window.addEventListener('online', () => { if (S && Q.pending.size) { Q.failed.clear(); flush(); } if (T) tRefresh(); });
  window.addEventListener('offline', () => { if (S && Q.pending.size) setSave('offline'); if (T) tStatus(); });
  window.addEventListener('beforeunload', e => { if (Q.pending.size) { e.preventDefault(); e.returnValue = ''; } });

  function setPrayer(d, k, v) {
    if (d > todayS()) return;
    const l = Object.assign({ student_id: A.user.id, log_date: d }, S.logs[d]);
    l[k] = l[k] === v ? null : v;
    S.logs[d] = l; markDirty('log:' + d);
  }
  let noteTimer = null, noteDate = null;
  function commitNote() { if (noteTimer) { clearTimeout(noteTimer); noteTimer = null; if (noteDate) markDirty('note:' + noteDate); noteDate = null; } }

  function studentShell() {
    const tabs = [['bugun', 'Bugün'], ['hafta', 'Hafta'], ['ay', 'Ay'], ['hesap', 'Hesabım']];
    let banner = '';
    if (!S.member) banner = joinFormHTML();
    else if (S.member.out_status === 'pending') banner = `<div class="card pending"><strong>${esc(S.member.out_class_name)}</strong> sınıfına katılma isteğin gönderildi. Öğretmenin onaylayınca kayıtların ona görünür. Bu arada kayıt tutabilirsin.</div>`;
    const v = S.tab === 'hafta' ? sWeek() : S.tab === 'ay' ? sMonth() : S.tab === 'hesap' ? sAccount() : sDay();
    return `<nav class="tabs no-print" aria-label="Bölümler">${tabs.map(([k, l]) => `<button data-act="tab" data-tab="${k}"${S.tab === k ? ' aria-current="page"' : ''}>${l}</button>`).join('')}</nav>
      ${S.loadErr ? `<div class="card pending" role="alert">Kayıtların sunucudan yüklenemedi: ${esc(S.loadErr)} <button class="btn small" data-act="reload-student">Tekrar dene</button></div>` : ''}${banner}${v}`;
  }
  function joinFormHTML() {
    return `<div class="card"><h2>Sınıfa katıl</h2><p class="muted">Öğretmeninin verdiği sınıf kodunu yaz. Öğretmenin seni onaylayana kadar kayıtların ona görünmez.</p>
      ${S.joinMsg ? `<p class="err" role="alert">${esc(S.joinMsg)}</p>` : ''}
      <label class="field">Sınıf kodu<input id="joinCode" type="text" maxlength="20" autocomplete="off" autocapitalize="characters"></label>
      <div class="row" style="margin-top:.8rem"><button class="btn" data-act="join">Katılma isteği gönder</button></div></div>`;
  }

  function sDay() {
    const t = todayS(); if (S.date > t) S.date = t;
    const d = S.date, l = S.logs[d] || {}, sess = sessOn(d), isT = d === t;
    const rows = PRAYERS.map((nm, i) => {
      const k = PKEYS[i], v = l[k] || null;
      return `<div class="prow"><span class="pname">${nm}</span>
        <div class="seg" role="group" aria-label="${nm} durumu">
          <button class="yes" data-act="pset" data-k="${k}" data-v="done" data-fk="p-${k}-done" aria-pressed="${v === 'done'}">✓ Kıldım</button>
          <button class="no" data-act="pset" data-k="${k}" data-v="missed" data-fk="p-${k}-missed" aria-pressed="${v === 'missed'}">✕ Kılmadım</button></div>
        <span class="pstate">${v === 'done' ? '✓ Kıldım olarak işaretli' : v === 'missed' ? '✕ Kılmadım olarak işaretli' : '○ Henüz işaretlemedim'}</span></div>`;
    }).join('');
    const sh = sess.map(x => {
      const parts = [KINDS[x.kind] || 'Kur’an okundu'];
      const a = [x.start_ref, x.start_page != null ? 's.' + x.start_page : ''].filter(Boolean).join(' '), b = [x.end_ref, x.end_page != null ? 's.' + x.end_page : ''].filter(Boolean).join(' ');
      return `<div class="sess"><div><strong>${esc(parts[0])}</strong><div class="meta">${esc([a && b ? a + ' → ' + b : a || b, x.minutes != null ? x.minutes + ' dk' : ''].filter(Boolean).join(' · ') || 'Ayrıntı girilmedi')}</div></div>
        <div class="row"><button class="btn ghost small" data-act="sess-edit" data-id="${x.id}">Düzenle</button><button class="btn danger small" data-act="sess-del" data-id="${x.id}">Sil</button></div></div>`;
    }).join('');
    const f = S.form;
    const form = f ? `<div class="card" style="background:var(--leaf)"><h3>${f.id ? 'Oturumu düzenle' : 'Ayrıntılı Kur’an kaydı'}</h3><p class="hint">Hiçbir alan zorunlu değil.</p>
      <div class="form-grid">
        <label class="field">Okuma türü<select data-bind="f-kind"><option value="">Belirtme</option>${Object.entries(KINDS).map(([k, n]) => `<option value="${k}"${f.kind === k ? ' selected' : ''}>${n}</option>`).join('')}</select></label>
        <label class="field">Süre (dakika)<input type="number" min="0" max="1440" inputmode="numeric" data-bind="f-minutes" value="${esc(f.minutes)}"></label>
        <label class="field">Başlangıç sure veya cüz<input type="text" list="surahs" maxlength="60" data-bind="f-start_ref" value="${esc(f.start_ref)}"></label>
        <label class="field">Başlangıç sayfası<input type="number" min="0" max="1000" inputmode="numeric" data-bind="f-start_page" value="${esc(f.start_page)}"></label>
        <label class="field">Bitiş sure veya cüz<input type="text" list="surahs" maxlength="60" data-bind="f-end_ref" value="${esc(f.end_ref)}"></label>
        <label class="field">Bitiş sayfası<input type="number" min="0" max="1000" inputmode="numeric" data-bind="f-end_page" value="${esc(f.end_page)}"></label></div>
      <datalist id="surahs">${SURAHS.map(s => `<option value="${esc(s)}"></option>`).join('')}</datalist>
      <p class="err" id="formErr" role="alert"></p>
      <div class="row" style="margin-top:.8rem"><button class="btn" data-act="sess-save">Kaydet</button><button class="btn ghost" data-act="sess-cancel">Vazgeç</button></div></div>` : '';
    return `
    <section class="daynav no-print" aria-label="Gün seçimi">
      <button class="btn ghost" data-act="day-prev" data-fk="dprev">‹ Önceki gün</button>
      <div class="daypick"><h2>${esc(fmtLong(d))}</h2><p class="hint" style="margin:0">${isT ? 'Bugün' : 'Geçmiş bir gündesin'}</p>
        <label class="sr-only" for="dayInput">Tarih seç</label><input id="dayInput" type="date" max="${t}" value="${d}" data-bind="day-date"></div>
      <button class="btn ghost" data-act="day-next" data-fk="dnext"${d >= t ? ' disabled' : ''}>Sonraki gün ›</button>
    </section>
    ${isT ? '' : '<div class="row" style="justify-content:center;margin-top:.6rem"><button class="btn ghost" data-act="day-today">Bugüne dön</button></div>'}
    ${unsyncedHTML()}
    <section class="card" aria-label="Namazlar"><h2>Namazlar</h2>${rows}
      <p class="hint">Bir düğmeye tekrar dokunursan işaret kalkar ve “henüz işaretlemedim” olur. Boş bırakılan vakit “kılmadım” sayılmaz.</p></section>
    <section class="card" aria-label="Kur’an"><h2>Kur’an</h2>
      ${sh || '<p class="muted">Bu gün için Kur’an kaydı yok.</p>'}
      ${f ? '' : `<div class="row" style="margin-top:.8rem"><button class="btn" data-act="sess-quick">${isT ? 'Bugün' : 'Bu gün'} Kur’an okudum</button><button class="btn ghost" data-act="sess-new">Ayrıntılı kayıt ekle</button></div>`}
    </section>${form}
    <section class="card" aria-label="Özel not"><label class="field" for="noteInput" style="margin-top:0">Özel günlük not (isteğe bağlı)</label>
      <textarea id="noteInput" maxlength="500" data-bind="note">${esc(S.notes[d] || '')}</textarea>
      <p class="hint">Bu not özeldir; öğretmenin dahil kimse göremez.</p></section>`;
  }
  function sWeek() {
    const s = S.wk, e = addDays(s, 6), t = todayS(), st = statsFor(weekDates(s), infoS), nextOk = addDays(s, 7) <= t;
    return `<section class="card"><div class="navbar no-print"><button class="btn ghost" data-act="week-prev">‹ Önceki hafta</button><h2>${esc(rangeLabel(s, e))}</h2><button class="btn ghost" data-act="week-next"${nextOk ? '' : ' disabled'}>Sonraki hafta ›</button></div>
      ${s === weekStart(t) ? '' : '<div class="row" style="justify-content:center;margin-top:.5rem"><button class="btn ghost" data-act="week-this">Bu haftaya dön</button></div>'}
      ${gridHTML(s, infoS, { link: true, caption: 'Haftalık çizelge' })}${legendHTML()}<p class="hint">Bir güne ait başlığa dokunarak o günü düzenleyebilirsin.</p></section>
      <section class="card"><h3>Bu haftanın özeti</h3>${factsHTML(st)}</section>`;
  }
  function sMonth() {
    const ms = S.mon, t = todayS(), st = statsFor(monthDates(ms), infoS), nextOk = addMonths(ms, 1) <= t;
    return `<section class="card"><div class="navbar no-print"><button class="btn ghost" data-act="month-prev">‹ Önceki ay</button><h2>${esc(monthLabel(ms))}</h2><button class="btn ghost" data-act="month-next"${nextOk ? '' : ' disabled'}>Sonraki ay ›</button></div>
      ${ms === monthStart(t) ? '' : '<div class="row" style="justify-content:center;margin-top:.5rem"><button class="btn ghost" data-act="month-this">Bu aya dön</button></div>'}
      ${monthHTML(ms, infoS, true)}<div class="legend"><span>n✓ = kıldım, n✕ = kılmadım, ○ = hiç işaret yok, K = Kur’an oturumu</span></div></section>
      <section class="card"><h3>${esc(monthLabel(ms))} özeti</h3>${factsHTML(st)}</section>`;
  }
  function sAccount() {
    return `<section class="card"><h2>Hesabım</h2><p>Rumuz: <strong>${esc(A.profile.nickname)}</strong></p>
      <p>Sınıf: ${S.member ? `<strong>${esc(S.member.out_class_name)}</strong> (${S.member.out_status === 'active' ? 'onaylı' : 'onay bekliyor'})` : 'Henüz bir sınıfa bağlı değilsin'}</p>
      ${S.member ? '<div class="row"><button class="btn ghost" data-act="leave">Sınıftan ayrıl</button></div>' : ''}</section>
      <section class="card"><h3>Kimler neyi görür?</h3><ul>
        <li>Onaylı sınıf öğretmenin: namaz durumlarını ve Kur’an oturumlarını görür.</li>
        <li>Kimse (öğretmenin dahil): özel günlük notlarını göremez.</li>
        <li>Diğer öğrenciler: hiçbir kaydını göremez.</li></ul></section>
      <section class="card"><h3>Verilerim</h3><p class="muted">Kayıtlarını bilgisayarına indirebilir, daha sonra geri yükleyebilirsin.</p>
        <div class="row"><button class="btn ghost" data-act="export">Verilerimi indir</button>
        <label class="btn ghost" style="cursor:pointer">Yedekten geri yükle<input type="file" accept=".json,application/json" data-bind="restore-file" class="sr-only"></label>
        <button class="btn danger" data-act="wipe">Tüm kayıtlarımı sil</button></div>
        <p class="hint">“Tüm kayıtlarımı sil” kayıtlarını ve sınıf üyeliğini kaldırır. Hesabın silinsin istiyorsan öğretmeninden yöneticiye bildirmesini iste.</p></section>`;
  }

  async function studentAct(a, b) {
    const t = todayS();
    if (b.dataset.fk) ui_fk = b.dataset.fk;
    switch (a) {
      case 'tab': commitNote(); S.tab = b.dataset.tab; render(true); break;
      case 'reload-student': await initStudent(); break;
      case 'retry-save': Q.failed.clear(); flush(); break;
      case 'day-prev': commitNote(); S.date = addDays(S.date, -1); S.form = null; render(); break;
      case 'day-next': commitNote(); if (S.date < t) S.date = addDays(S.date, 1); S.form = null; render(); break;
      case 'day-today': commitNote(); S.date = t; S.form = null; render(); break;
      case 'goto-day': commitNote(); S.date = b.dataset.date; S.tab = 'bugun'; S.form = null; render(true); break;
      case 'pset': setPrayer(S.date, b.dataset.k, b.dataset.v); render(); break;
      case 'sess-quick': { const id = uuid(); S.sess[id] = { id, student_id: A.user.id, log_date: S.date, kind: null, _ts: new Date().toISOString() }; markDirty('sess:' + id); render(); break; }
      case 'sess-new': S.form = { id: null, kind: '', start_ref: '', start_page: '', end_ref: '', end_page: '', minutes: '' }; render(); break;
      case 'sess-edit': { const x = S.sess[b.dataset.id]; S.form = { id: x.id, kind: x.kind || '', start_ref: x.start_ref || '', start_page: x.start_page == null ? '' : x.start_page, end_ref: x.end_ref || '', end_page: x.end_page == null ? '' : x.end_page, minutes: x.minutes == null ? '' : x.minutes }; render(); break; }
      case 'sess-cancel': S.form = null; render(); break;
      case 'sess-save': {
        const f = S.form, num = (v, max) => { if (v === '' || v == null) return null; const n = Number(v); return Number.isInteger(n) && n >= 0 && n <= max ? n : NaN; };
        const sp = num(f.start_page, 1000), ep = num(f.end_page, 1000), mn = num(f.minutes, 1440);
        if ([sp, ep, mn].some(Number.isNaN)) { document.getElementById('formErr').textContent = 'Sayfa 0-1000, süre 0-1440 arasında bir tam sayı olmalı.'; return; }
        const id = f.id || uuid(), old = S.sess[id] || {};
        S.sess[id] = { id, student_id: A.user.id, log_date: old.log_date || S.date, kind: f.kind || null, start_ref: f.start_ref.trim().slice(0, 60) || null, start_page: sp, end_ref: f.end_ref.trim().slice(0, 60) || null, end_page: ep, minutes: mn, created_at: old.created_at, _ts: old._ts || new Date().toISOString() };
        S.form = null; markDirty('sess:' + id); render(); break;
      }
      case 'sess-del': if (confirm('Bu Kur’an oturumu silinsin mi?')) { delete S.sess[b.dataset.id]; markDirty('sess:' + b.dataset.id); render(); } break;
      case 'week-prev': S.wk = addDays(S.wk, -7); render(); break;
      case 'week-next': if (addDays(S.wk, 7) <= t) S.wk = addDays(S.wk, 7); render(); break;
      case 'week-this': S.wk = weekStart(t); render(); break;
      case 'month-prev': S.mon = addMonths(S.mon, -1); render(); break;
      case 'month-next': if (addMonths(S.mon, 1) <= t) S.mon = addMonths(S.mon, 1); render(); break;
      case 'month-this': S.mon = monthStart(t); render(); break;
      case 'join': {
        const code = document.getElementById('joinCode').value.trim(); if (!code) return;
        const { error } = await sb.rpc('join_class', { p_code: code });
        if (error) { S.joinMsg = isNetErr(error) ? errText(error) : error.message; render(); return; }
        S.joinMsg = ''; const m = await sb.rpc('my_membership'); S.member = (m.data && m.data[0]) || null; toast('Katılma isteği gönderildi.'); render(); break;
      }
      case 'leave':
        if (confirm('Sınıftan ayrılırsan öğretmenin kayıtlarını artık göremez. Kayıtların sende kalır. Emin misin?')) {
          const { error } = await sb.from('memberships').delete().eq('student_id', A.user.id);
          if (error) { toast(errText(error)); return; } S.member = null; toast('Sınıftan ayrıldın.'); render();
        } break;
      case 'export': {
        const out = { app: BACKUP_APP, version: 1, exportedAt: new Date().toISOString(), logs: Object.values(S.logs).map(l => { const o = { log_date: l.log_date }; PKEYS.forEach(k => { o[k] = l[k] || null; }); return o; }),
          sessions: Object.values(S.sess).map(x => ({ id: x.id, log_date: x.log_date, kind: x.kind || null, start_ref: x.start_ref || null, start_page: x.start_page == null ? null : x.start_page, end_ref: x.end_ref || null, end_page: x.end_page == null ? null : x.end_page, minutes: x.minutes == null ? null : x.minutes })),
          notes: Object.entries(S.notes).filter(([, n]) => n).map(([log_date, note]) => ({ log_date, note })) };
        download(`ibadet-takip-yedek-${slug(A.profile.nickname)}-${t}.json`, JSON.stringify(out)); toast('Yedek indirildi.'); break;
      }
      case 'wipe':
        if (confirm('Tüm kayıtların ve sınıf üyeliğin sunucudan silinecek. Bu işlem geri alınamaz. Emin misin?')) {
          const { error } = await sb.rpc('delete_my_data');
          if (error) { toast(errText(error)); return; }
          S.logs = {}; S.sess = {}; S.notes = {}; S.member = null; Q.pending.clear(); Q.failed.clear(); toast('Kayıtların silindi.'); render();
        } break;
    }
  }
  async function restoreFile(file) {
    if (!file) return;
    try {
      const o = JSON.parse(await file.text());
      if (!o || o.app !== BACKUP_APP || !Array.isArray(o.logs) || !Array.isArray(o.sessions) || !Array.isArray(o.notes)) throw new Error('Bu dosya geçerli bir yedek değil.');
      if (o.logs.length + o.sessions.length + o.notes.length > 5000) throw new Error('Yedek dosyası çok büyük.');
      const t = todayS(), okSt = v => v === 'done' || v === 'missed' || v == null, okInt = (v, m) => v == null || (Number.isInteger(v) && v >= 0 && v <= m), okStr = v => v == null || (typeof v === 'string' && v.length <= 60);
      const L = [], Se = [], N = [];
      o.logs.forEach(r => { if (isDate(r.log_date) && r.log_date <= t && PKEYS.every(k => okSt(r[k]))) L.push(r); });
      o.sessions.forEach(r => { if (/^[0-9a-f-]{36}$/i.test(r.id) && isDate(r.log_date) && r.log_date <= t && (r.kind == null || KINDS[r.kind]) && okStr(r.start_ref) && okStr(r.end_ref) && okInt(r.start_page, 1000) && okInt(r.end_page, 1000) && okInt(r.minutes, 1440)) Se.push(r); });
      o.notes.forEach(r => { if (isDate(r.log_date) && r.log_date <= t && typeof r.note === 'string' && r.note.length && r.note.length <= 500) N.push(r); });
      if (!confirm(`Yedekte ${L.length} günlük kayıt, ${Se.length} Kur’an oturumu ve ${N.length} not var. Aynı günlere ait mevcut kayıtların üzerine yazılacak. Devam edilsin mi?`)) return;
      L.forEach(r => { const l = { student_id: A.user.id, log_date: r.log_date }; PKEYS.forEach(k => { l[k] = r[k] || null; }); S.logs[r.log_date] = l; markDirty('log:' + r.log_date); });
      Se.forEach(r => { S.sess[r.id] = Object.assign({ student_id: A.user.id, _ts: new Date().toISOString() }, r); markDirty('sess:' + r.id); });
      N.forEach(r => { S.notes[r.log_date] = r.note; markDirty('note:' + r.log_date); });
      toast('Yedek yüklendi; sunucuya kaydediliyor.'); render();
    } catch (e) { toast(e.message || 'Yedek okunamadı.'); }
  }

  /* =====================================================================
   *  ÖĞRETMEN
   * ===================================================================== */
  async function initTeacher() {
    const t = todayS(), w = weekStart(t);
    T = { tab: 'ozet', classes: [], cid: null, members: [], logs: new Map(), sess: new Map(), range: { from: w, to: addDays(w, 6) > t ? t : addDays(w, 6) }, date: t, sid: null, view: 'hafta',
      live: 'connecting', lastSync: null, syncErr: '', loading: false, channel: null, poll: null, timer: null, running: false, again: false, rep: false, msg: '' };
    try { await tLoadClasses(); } catch (e) { T.syncErr = errText(e); }
    A.screen = 'teacher'; render(true);
    if (T.cid) { await tRefresh(); tSubscribe(); }
    T.poll = setInterval(() => { if (document.visibilityState === 'visible') tRefresh(); }, 45000);
  }
  function tTeardown() { if (!T) return; if (T.poll) clearInterval(T.poll); if (T.timer) clearTimeout(T.timer); if (T.channel) { try { sb.removeChannel(T.channel); } catch (e) { /* yoksay */ } } }
  async function tLoadClasses() {
    const { data, error } = await sb.from('classes').select('id,name,join_code,join_open,created_at').order('created_at');
    if (error) throw error;
    T.classes = data; if (!data.some(c => c.id === T.cid)) T.cid = data[0] ? data[0].id : null;
  }
  const tClass = () => T.classes.find(c => c.id === T.cid);
  const tActive = () => T.members.filter(m => m.status === 'active').sort((a, b) => trSort(a.nickname, b.nickname));
  const tPending = () => T.members.filter(m => m.status === 'pending').sort((a, b) => trSort(a.nickname, b.nickname));
  function tWindow() {
    const t = todayS(), w = weekStart(T.date);
    let from = [T.range.from, w].sort()[0], to = [T.range.to, T.date, addDays(w, 6)].sort().slice(-1)[0];
    if (to > t) to = t; if (from > to) from = to;
    return { from, to };
  }
  async function tRefresh() {
    if (!T || !T.cid) return;
    if (T.running) { T.again = true; return; }
    T.running = true; T.loading = true; tStatus();
    try {
      const cid = T.cid;
      const mem = await fetchAll(() => sb.from('memberships').select('student_id,status,created_at').eq('class_id', cid).order('student_id'));
      const ids = mem.map(m => m.student_id);
      let profs = [];
      if (ids.length) profs = await fetchAll(() => sb.from('profiles').select('id,nickname').in('id', ids).order('id'));
      const nick = {}; profs.forEach(p => { nick[p.id] = p.nickname; });
      const members = mem.map(m => ({ student_id: m.student_id, status: m.status, nickname: nick[m.student_id] || '(bilinmiyor)' }));
      const act = members.filter(m => m.status === 'active').map(m => m.student_id), win = tWindow();
      const logs = new Map(), sess = new Map();
      if (act.length) {
        const [lr, sr] = await Promise.all([
          fetchAll(() => sb.from('daily_logs').select('*').in('student_id', act).gte('log_date', win.from).lte('log_date', win.to).order('student_id').order('log_date')),
          fetchAll(() => sb.from('quran_sessions').select('*').in('student_id', act).gte('log_date', win.from).lte('log_date', win.to).order('id'))
        ]);
        lr.forEach(r => logs.set(r.student_id + '|' + r.log_date, r));
        sr.forEach(r => { const k = r.student_id + '|' + r.log_date; if (!sess.has(k)) sess.set(k, []); sess.get(k).push(r); });
      }
      if (cid !== T.cid) return;
      T.members = members; T.logs = logs; T.sess = sess; T.lastSync = new Date(); T.syncErr = '';
      if (!tActive().some(m => m.student_id === T.sid)) T.sid = tActive()[0] ? tActive()[0].student_id : null;
    } catch (e) { T.syncErr = errText(e); }
    T.running = false; T.loading = false;
    if (T.again) { T.again = false; setTimeout(tRefresh, 0); }
    safeRender();
  }
  function tSubscribe() {
    if (T.channel) { try { sb.removeChannel(T.channel); } catch (e) { /* yoksay */ } T.channel = null; }
    const ch = sb.channel('izle-' + A.user.id);
    const sched = () => { clearTimeout(T.timer); T.timer = setTimeout(tRefresh, 700); };
    ['daily_logs', 'quran_sessions', 'memberships'].forEach(tb => ch.on('postgres_changes', { event: '*', schema: 'public', table: tb }, sched));
    ch.subscribe(status => {
      T.live = status === 'SUBSCRIBED' ? 'live' : (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') ? 'down' : 'connecting';
      tStatus(); if (T.live === 'live') tRefresh();
    });
    T.channel = ch;
  }
  const tDown = () => T.live === 'down' || !!T.syncErr || !navigator.onLine;
  function tStatusHTML() {
    let chip;
    if (T.loading) chip = '<span class="status warn" id="liveChip" role="status">⟳ Güncelleniyor…</span>';
    else if (tDown()) chip = '<span class="status bad" id="liveChip" role="status">⚠ Canlı bağlantı yok</span>';
    else if (!T.cid) chip = '<span id="liveChip"></span>';
    else if (T.live === 'connecting') chip = '<span class="status warn" id="liveChip" role="status">⟳ Bağlanıyor…</span>';
    else chip = '<span class="status" id="liveChip" role="status">● Canlı bağlantı</span>';
    return chip + (T.cid ? ` <span class="chip" id="syncChip">Son güncelleme: ${fmtTime(T.lastSync)}</span>` : '');
  }
  function tBannerHTML() {
    return `<div id="staleBanner">${tDown() ? `<div class="banner bad" role="alert">Canlı bağlantı kurulamadı${T.syncErr ? ' (' + esc(T.syncErr) + ')' : ''}. Aşağıdaki veriler <strong>${T.lastSync ? fmtTime(T.lastSync) + ' anındaki' : 'eski'}</strong> veriler olabilir; güncel kabul etmeyin. Bağlantı gelince otomatik yenilenir.</div>` : ''}</div>`;
  }
  function tStatus() { const a = document.getElementById('tStatus'); if (a) a.innerHTML = tStatusHTML(); const b = document.getElementById('staleBanner'); if (b) b.outerHTML = tBannerHTML(); }
  function safeRender() {
    const el = document.activeElement;
    if (el && el.matches && el.matches('input,textarea,select') && app.contains(el)) { T.rep = true; tStatus(); return; }
    render();
  }

  function infoT(sid) { return d => mkInfo(T.logs.get(sid + '|' + d), T.sess.get(sid + '|' + d)); }
  function lastActivity(sid) {
    let best = '';
    T.logs.forEach((r, k) => { if (k.startsWith(sid + '|') && r.updated_at > best) best = r.updated_at; });
    T.sess.forEach((arr, k) => { if (k.startsWith(sid + '|')) arr.forEach(r => { if (r.updated_at > best) best = r.updated_at; }); });
    return best;
  }

  function teacherShell() {
    const tabs = [['ozet', 'Özet'], ['ogrenciler', 'Öğrenciler'], ['rapor', 'Rapor'], ['sinif', 'Sınıf ayarları']];
    if (!T.classes.length) return tCreateFirst();
    const cls = T.classes.length > 1 ? `<label class="field no-print" style="max-width:320px">Sınıf<select data-bind="t-class">${T.classes.map(c => `<option value="${c.id}"${c.id === T.cid ? ' selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>` : '';
    const pend = tPending().length ? `<div class="card pending no-print"><strong>${tPending().length} öğrenci</strong> sınıfa katılmak için onayını bekliyor. <button class="btn small" data-act="tab" data-tab="sinif">Onay ekranına git</button></div>` : '';
    const body = T.tab === 'ogrenciler' ? tStudents() : T.tab === 'rapor' ? tReport() : T.tab === 'sinif' ? tSettings() : tOverview();
    return `${cls}<nav class="tabs no-print" aria-label="Bölümler" style="margin-top:.6rem">${tabs.map(([k, l]) => `<button data-act="tab" data-tab="${k}"${T.tab === k ? ' aria-current="page"' : ''}>${l}</button>`).join('')}</nav>${pend}${body}`;
  }
  function tCreateFirst() {
    return `<section class="card" style="max-width:520px;margin:2rem auto"><h2>İlk sınıfını oluştur</h2><p class="muted">Sınıf oluşturunca öğrencilerine verebileceğin bir katılım kodu üretilir.</p>
      ${T.msg ? `<p class="err" role="alert">${esc(T.msg)}</p>` : ''}<label class="field">Sınıf adı (örn. 6-A Hafta Sonu Grubu)<input id="newClass" type="text" maxlength="60"></label>
      <div class="row" style="margin-top:.8rem"><button class="btn" data-act="class-create">Sınıfı oluştur</button></div></section>`;
  }
  function filterBar(opts) {
    opts = opts || {};
    return `<section class="card no-print"><div class="filters">
      ${opts.date ? `<label class="field" style="margin:0">Tarih<input type="date" max="${todayS()}" value="${T.date}" data-bind="t-date"></label>` : ''}
      ${opts.range ? `<label class="field" style="margin:0">Başlangıç<input type="date" value="${T.range.from}" data-bind="t-from"></label><label class="field" style="margin:0">Bitiş<input type="date" value="${T.range.to}" data-bind="t-to"></label>
      <div class="quick"><button class="btn ghost small" data-act="t-quick" data-q="week">Bu hafta</button><button class="btn ghost small" data-act="t-quick" data-q="lastweek">Geçen hafta</button><button class="btn ghost small" data-act="t-quick" data-q="month">Bu ay</button><button class="btn ghost small" data-act="t-quick" data-q="lastmonth">Geçen ay</button></div>` : ''}</div></section>`;
  }

  function tOverview() {
    const d = T.date, act = tActive(), t = todayS();
    let made = 0, qd = 0;
    const rows = act.map(m => {
      const i = infoT(m.student_id)(d), wk = statsFor(weekDates(weekStart(d)), infoT(m.student_id));
      if (i.has) made++; if (i.sess.length) qd++;
      return `<tr><th scope="row"><button class="linkbtn" data-act="t-open" data-id="${m.student_id}">${esc(m.nickname)}</button></th>
        <td>${i.has ? i.p.map(markHTML).join(' ') : '<span class="badge none">Kayıt yok</span>'}</td>
        <td class="c">${i.sess.length ? `<span class="m q">${i.sess.length}</span>` : '–'}</td>
        <td class="c">${wk.recDays} / ${wk.days} gün</td><td class="c small">${esc(fmtStamp(lastActivity(m.student_id)))}</td></tr>`;
    }).join('');
    const wkS = weekStart(d);
    return filterBar({ date: true }) + `<section class="card"><h2>${esc(tClass().name)} · ${esc(fmtLong(d))}</h2>
      <ul class="facts"><li><span>Sınıftaki onaylı öğrenci</span><strong>${act.length}</strong></li>
        <li><span>Bu tarihte kayıt oluşturan</span><strong>${made}</strong></li>
        <li><span>Bu tarihte kayıt oluşturmayan</span><strong>${act.length - made}</strong></li>
        <li><span>Bu tarihte Kur’an kaydı olan</span><strong>${qd}</strong></li></ul>
      ${act.length ? `<div class="gridwrap"><table class="list"><thead><tr><th scope="col">Öğrenci (A-Z)</th><th scope="col">${PRAYERS.join(' · ')}</th><th scope="col" class="c">Kur’an</th><th scope="col" class="c">Hafta: kayıt günü<br><span class="small">${esc(rangeLabel(wkS, addDays(wkS, 6)))}</span></th><th scope="col" class="c">Son kayıt zamanı</th></tr></thead><tbody>${rows}</tbody></table></div>${legendHTML()}
      <p class="hint">“Kayıt yok”, öğrencinin o gün hiçbir şey işaretlemediği anlamına gelir; “kılmadı” anlamına gelmez. Öğrenciler sıralanmaz, alfabetik listelenir.</p>` : '<div class="empty-state"><h3>Henüz onaylı öğrenci yok</h3><p>Öğrencilerine sınıf kodunu ver; katılma isteklerini “Sınıf ayarları”ndan onayla.</p></div>'}</section>`;
  }

  function tStudents() {
    const act = tActive(), dates = daysBetween(T.range.from, T.range.to);
    const rows = act.map(m => {
      const s = statsFor(dates, infoT(m.student_id));
      return `<tr><th scope="row"><button class="linkbtn" data-act="t-open" data-id="${m.student_id}">${esc(m.nickname)}</button></th><td class="small">${esc(fmtStamp(lastActivity(m.student_id)))}</td>
        <td class="c">${s.recDays} / ${s.days} gün</td><td class="c">${s.qDays} gün</td><td><button class="btn ghost small" data-act="t-open" data-id="${m.student_id}">Ayrıntı</button></td></tr>`;
    }).join('');
    const m = act.find(x => x.student_id === T.sid);
    let detail = '';
    if (T.sid && m && T.detail) {
      const get0 = infoT(T.sid), t = todayS(), get = d => (d >= T.range.from && d <= T.range.to ? get0(d) : null);
      let body = '';
      if (T.view === 'hafta') {
        const ws = []; let w = weekStart(T.range.from); while (w <= T.range.to && ws.length < 60) { ws.push(w); w = addDays(w, 7); }
        body = ws.map(w => { const s = statsFor(weekDates(w).filter(d => d >= T.range.from && d <= T.range.to), get0); return `<div style="margin-top:1rem"><h3>${esc(rangeLabel(w, addDays(w, 6)))}</h3>${gridHTML(w, get, { caption: rangeLabel(w, addDays(w, 6)) })}<p class="hint">${s.days ? `Kayıt girilen gün: ${s.recDays} / ${s.days} · Kıldım ${s.done} · Kılmadım ${s.missed} · İşaretlenmemiş ${s.unmarked}` : ''}</p></div>`; }).join('');
      } else {
        const ms = []; let mm = monthStart(T.range.from); while (mm <= T.range.to && ms.length < 14) { ms.push(mm); mm = addMonths(mm, 1); }
        body = ms.map(x => `<div style="margin-top:1rem"><h3>${esc(monthLabel(x))}</h3>${factsHTML(statsFor(monthDates(x).filter(d => d >= T.range.from && d <= T.range.to), get0), false)}${monthHTML(x, get, false)}</div>`).join('');
      }
      const sessList = daysBetween(T.range.from, T.range.to).filter(d => d <= t).flatMap(d => get0(d).sess.map(x => ({ d, x })));
      detail = `<section class="card"><div class="row" style="justify-content:space-between"><h2>${esc(m.nickname)} · ${esc(rangeLabel(T.range.from, T.range.to))}</h2>
        <div class="seg sm no-print" role="group" aria-label="Görünüm"><button data-act="t-view" data-v="hafta" aria-pressed="${T.view === 'hafta'}" class="yes">Haftalık</button><button data-act="t-view" data-v="ay" aria-pressed="${T.view === 'ay'}" class="yes">Aylık</button></div></div>
        ${body}${legendHTML(true)}
        <h3 style="margin-top:1.2rem">Kur’an oturumları</h3>${sessList.length ? `<ul>${sessList.map(({ d, x }) => `<li>${esc(fmtShort(d))}: ${esc(KINDS[x.kind] || 'Kur’an okundu')}${x.start_ref || x.end_ref ? ' · ' + esc([x.start_ref, x.end_ref].filter(Boolean).join(' → ')) : ''}${x.start_page != null || x.end_page != null ? ' · s.' + esc([x.start_page, x.end_page].filter(v => v != null).join('–')) : ''}${x.minutes != null ? ' · ' + x.minutes + ' dk' : ''}</li>`).join('')}</ul>` : '<p class="muted">Bu dönemde Kur’an oturumu yok.</p>'}</section>`;
    }
    return filterBar({ range: true }) + `<section class="card"><h2>Öğrenciler</h2>${act.length ? `<table class="list"><thead><tr><th scope="col">Rumuz (A-Z)</th><th scope="col">Son kayıt zamanı</th><th scope="col" class="c">Seçili dönemde kayıt günü</th><th scope="col" class="c">Kur’an günü</th><th scope="col"><span class="sr-only">İşlem</span></th></tr></thead><tbody>${rows}</tbody></table>
      <p class="hint">“Kayıt günü”, öğrencinin en az bir vakti işaretlediği veya Kur’an oturumu girdiği günlerdir. Dönemin henüz gelmemiş günleri sayılmaz.</p>` : '<div class="empty-state"><h3>Henüz onaylı öğrenci yok</h3></div>'}</section>${detail}`;
  }

  function tReport() {
    const act = tActive(), dates = daysBetween(T.range.from, T.range.to), t = todayS(), showDays = dates.length <= 31;
    const printed = new Date().toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
    const head = showDays ? dates.map(d => `<th scope="col">${DOW[(parse(d).getDay() + 6) % 7]}<br><span class="dn">${parse(d).getDate()}</span></th>`).join('') : '';
    const rows = act.map(m => {
      const get = infoT(m.student_id), s = statsFor(dates, get);
      const cells = showDays ? dates.map(d => {
        if (d > t) return '<td></td>'; const i = get(d);
        if (!i.has) return '<td class="nodata" title="Kayıt yok">○</td>';
        const dn = i.p.filter(v => v === 'done').length, ms = i.p.filter(v => v === 'missed').length;
        return `<td>${dn}✓${ms ? ' ' + ms + '✕' : ''}${i.sess.length ? ' K' : ''}</td>`;
      }).join('') : '';
      return `<tr><th scope="row" class="l">${esc(m.nickname)}</th>${cells}<td>${s.recDays}/${s.days}</td><td>${s.done}</td><td>${s.missed}</td><td>${s.unmarked}</td><td>${s.qDays}</td><td>${s.sessions}</td><td>${s.minutes}</td></tr>`;
    }).join('');
    return filterBar({ range: true }) + `<section class="card no-print"><div class="row"><button class="btn" data-act="print">Yazdır / PDF olarak kaydet</button><button class="btn ghost" data-act="export-csv"${act.length ? '' : ' disabled'}>CSV indir</button></div>
      <p class="hint">PDF için tarayıcının yazdırma ekranında “PDF olarak kaydet” seçeneğini kullan; uygulama sunucuda ayrıca PDF üretmez.</p></section>
      <div class="report"><h2>${esc(tClass().name)} — İbadet Takip Raporu</h2><p class="muted">${esc(rangeLabel(T.range.from, T.range.to))} · Hazırlanma: ${esc(printed)} · Son güncelleme: ${esc(fmtTime(T.lastSync))}</p>
      ${act.length ? `<div class="gridwrap"><table class="classrep"><thead><tr><th class="l" scope="col">Rumuz</th>${head}<th scope="col">Kayıt günü</th><th scope="col">✓ Kıldım</th><th scope="col">✕ Kılmadım</th><th scope="col">○ İşaretsiz</th><th scope="col">Kur’an günü</th><th scope="col">Oturum</th><th scope="col">Dakika</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<p>Bu sınıfta onaylı öğrenci yok.</p>'}
      <p class="foot">Hücrelerde: n✓ kıldım, n✕ kılmadım, K Kur’an oturumu var, ○ o gün hiçbir kayıt girilmemiş. “İşaretsiz”, kayıt girilmeyen veya boş bırakılan vakitlerdir ve “kılmadım” anlamına gelmez. Hesaplar yalnızca bugüne kadarki günleri kapsar (gün sayısı × 5 vakit). Özel notlar rapora dahil edilmez.</p></div>`;
  }

  function tSettings() {
    const c = tClass(), pend = tPending(), act = tActive();
    return `<section class="card"><h2>Sınıf ayarları</h2>
      <label class="field" style="margin-top:0">Sınıf adı<input id="className" type="text" maxlength="60" value="${esc(c.name)}"></label>
      <div class="row" style="margin-top:.6rem"><button class="btn ghost" data-act="class-rename">Adı kaydet</button></div>
      <h3 style="margin-top:1.2rem">Katılım kodu</h3><p><span class="joincode" id="jc">${esc(c.join_code)}</span></p>
      <p class="hint">Kodu öğrencilere sözlü veya yazılı verin. Kod tek başına erişim vermez: öğrenci kendi hesabını açar ve siz onaylayana kadar kayıtları size görünmez.</p>
      <div class="row"><button class="btn ghost" data-act="copy-code">Kodu kopyala</button><button class="btn ghost" data-act="class-regen">Kodu yenile</button>
        <label class="row" style="cursor:pointer"><input type="checkbox" data-bind="join-open"${c.join_open ? ' checked' : ''} style="width:22px;height:22px"> Yeni katılımlara açık</label></div></section>
      <section class="card${pend.length ? ' pending' : ''}"><h3>Onay bekleyenler</h3>${pend.length ? pend.map(m => `<div class="sess"><strong>${esc(m.nickname)}</strong><div class="row"><button class="btn small" data-act="approve" data-id="${m.student_id}">Onayla</button><button class="btn danger small" data-act="remove" data-id="${m.student_id}" data-nick="${esc(m.nickname)}">Reddet</button></div></div>`).join('') : '<p class="muted">Bekleyen istek yok.</p>'}
        <p class="hint">Tanımadığın bir rumuzu onaylama. Onaylanana kadar bu öğrencinin kayıtlarını göremezsin.</p></section>
      <section class="card"><h3>Sınıftaki öğrenciler (${act.length})</h3>${act.length ? act.map(m => `<div class="sess"><strong>${esc(m.nickname)}</strong><button class="btn danger small" data-act="remove" data-id="${m.student_id}" data-nick="${esc(m.nickname)}">Sınıftan çıkar</button></div>`).join('') : '<p class="muted">Henüz onaylı öğrenci yok.</p>'}
        <p class="hint">Sınıftan çıkarılan öğrencinin kayıtları silinmez; yalnızca sana görünmez olur.</p></section>
      <section class="card"><h3>Diğer</h3><div class="row"><button class="btn ghost" data-act="class-new">Yeni sınıf oluştur</button><button class="btn danger" data-act="class-delete">Bu sınıfı sil</button></div>
        <p class="hint">Sınıfı silmek üyelikleri kaldırır; öğrencilerin kendi kayıtları silinmez.</p></section>`;
  }

  async function teacherAct(a, b) {
    const t = todayS();
    switch (a) {
      case 'tab': T.tab = b.dataset.tab; render(true); break;
      case 't-quick': {
        const w = weekStart(t); let f, e;
        if (b.dataset.q === 'week') { f = w; e = addDays(w, 6); } else if (b.dataset.q === 'lastweek') { f = addDays(w, -7); e = addDays(w, -1); }
        else if (b.dataset.q === 'month') { f = monthStart(t); e = addDays(addMonths(f, 1), -1); } else { f = addMonths(monthStart(t), -1); e = addDays(monthStart(t), -1); }
        T.range = { from: f, to: e > t ? t : e }; render(); tRefresh(); break;
      }
      case 't-open': T.sid = b.dataset.id; T.detail = true; T.tab = 'ogrenciler'; render(true); break;
      case 't-view': T.view = b.dataset.v; render(); break;
      case 'print': window.print(); break;
      case 'export-csv': tCsv(); break;
      case 'class-create': case 'class-new': {
        const el = document.getElementById('newClass');
        const name = a === 'class-new' ? (prompt('Yeni sınıfın adı:') || '').trim() : (el ? el.value.trim() : '');
        if (!name) return;
        const { error } = await sb.rpc('create_class', { p_name: name });
        if (error) { T.msg = errText(error); toast(T.msg); render(); return; }
        T.msg = ''; await tLoadClasses(); T.cid = (T.classes[T.classes.length - 1] || {}).id || T.cid; T.tab = 'sinif'; render(true); await tRefresh(); tSubscribe(); break;
      }
      case 'class-rename': {
        const n = document.getElementById('className').value.trim(); if (!n) return;
        const { error } = await sb.from('classes').update({ name: n }).eq('id', T.cid);
        if (error) { toast(errText(error)); return; } tClass().name = n; toast('Sınıf adı kaydedildi.'); render(); break;
      }
      case 'class-regen':
        if (confirm('Eski kod geçersiz olacak. Yeni kod üretilsin mi?')) {
          const { data, error } = await sb.rpc('regenerate_join_code', { p_class_id: T.cid });
          if (error) { toast(errText(error)); return; } tClass().join_code = data; toast('Yeni kod üretildi.'); render();
        } break;
      case 'copy-code': toast((await copyText(tClass().join_code)) ? 'Kod kopyalandı.' : 'Kopyalanamadı; kodu elle seçip kopyala.'); break;
      case 'approve': {
        const { error } = await sb.from('memberships').update({ status: 'active' }).eq('class_id', T.cid).eq('student_id', b.dataset.id);
        if (error) { toast(errText(error)); return; } toast('Öğrenci onaylandı.'); await tRefresh(); break;
      }
      case 'remove':
        if (confirm(`${b.dataset.nick} sınıftan çıkarılsın mı? Kayıtlarını artık göremezsin.`)) {
          const { error } = await sb.from('memberships').delete().eq('class_id', T.cid).eq('student_id', b.dataset.id);
          if (error) { toast(errText(error)); return; } toast('Öğrenci sınıftan çıkarıldı.'); await tRefresh();
        } break;
      case 'class-delete':
        if (confirm('Bu sınıf silinecek ve tüm üyelikler kalkacak. Emin misin?')) {
          const { error } = await sb.from('classes').delete().eq('id', T.cid);
          if (error) { toast(errText(error)); return; } T.cid = null; await tLoadClasses(); render(true); if (T.cid) { await tRefresh(); tSubscribe(); }
        } break;
    }
  }
  function tCsv() {
    const t = todayS(), dates = daysBetween(T.range.from, T.range.to).filter(d => d <= t), L = { done: 'Kıldım', missed: 'Kılmadım' };
    const lines = [['Sınıf', 'Rumuz', 'Tarih', 'Kayıt'].concat(PRAYERS, ['Kur’an oturumu', 'Kur’an dakika']).map(csvCell).join(';')];
    tActive().forEach(m => { const get = infoT(m.student_id); dates.forEach(d => { const i = get(d);
      lines.push([tClass().name, m.nickname, d, i.has ? 'Var' : 'Yok'].concat(i.p.map(v => L[v] || 'İşaretlenmedi'), [i.sess.length, i.sess.reduce((a, x) => a + (x.minutes || 0), 0)]).map(csvCell).join(';')); }); });
    download(`ibadet-takip-${slug(tClass().name)}-${T.range.from}_${T.range.to}.csv`, '\uFEFF' + lines.join('\r\n'), 'text/csv;charset=utf-8'); toast('CSV indirildi.');
  }

  /* ---------- Çizim ---------- */
  let ui_fk = null;
  function header() {
    const right = A.profile ? `<span class="chip">${esc(A.profile.nickname)}${A.profile.role === 'teacher' ? ' · Öğretmen' : ''}</span>` +
      (A.screen === 'student' ? saveChipHTML() : A.screen === 'teacher' ? `<span id="tStatus">${tStatusHTML()}</span>` : '') + '<button class="btn ghost" data-act="signout">Çıkış</button>' : '';
    return `<header class="appbar no-print"><div class="brand">İbadet Takip Defterim</div><div class="who">${right}</div></header>${A.screen === 'teacher' && T ? tBannerHTML() : ''}`;
  }
  function authView() {
    const tab = A.authTab, isS = tab !== 'teacher';
    return `<section class="auth"><h1>İbadet Takip Defterim</h1><p class="lead">Kendi takibini yap, gelişimini fark et.</p>
      <div class="auth-tabs" role="group" aria-label="Giriş türü"><button data-act="authtab" data-t="student" aria-pressed="${tab === 'student'}">Öğrenci girişi</button><button data-act="authtab" data-t="signup" aria-pressed="${tab === 'signup'}">Yeni öğrenci</button><button data-act="authtab" data-t="teacher" aria-pressed="${tab === 'teacher'}">Öğretmen</button></div>
      <div class="card">
        <label class="field" style="margin-top:0">${isS ? 'Rumuz' : 'E-posta'}<input id="aId" type="${isS ? 'text' : 'email'}" autocomplete="username" autocapitalize="none" spellcheck="false" value="${esc(A.form.id)}"></label>
        <label class="field">Şifre<input id="aPw" type="password" autocomplete="${tab === 'signup' ? 'new-password' : 'current-password'}"></label>
        ${tab === 'signup' ? '<label class="field">Sınıf kodu<input id="aCode" type="text" autocomplete="off" autocapitalize="characters" value="${esc(A.form.code)}"></label><p class="hint">Rumuzu öğretmeninin söylediği gibi veya kendin seç. Gerçek adını yazmak zorunda değilsin. Şifreni kimseyle paylaşma.</p>' : ''}
        ${A.authMsg ? `<p class="err" role="alert" style="margin-top:.8rem">${esc(A.authMsg)}</p>` : ''}
        <div class="row" style="margin-top:1rem"><button class="btn" data-act="primary"${A.busy ? ' disabled' : ''}>${A.busy ? 'Lütfen bekle…' : tab === 'signup' ? 'Hesap oluştur' : 'Giriş yap'}</button></div></div>
      <p class="hint">Öğretmen hesapları uygulama yöneticisi tarafından açılır. Şifreni unutursan öğretmenine haber ver.</p></section>`;
  }
  function render(top) {
    const y = window.scrollY, fk = ui_fk; ui_fk = null;
    let body = '';
    if (A.screen === 'loading') body = '<p class="muted" style="text-align:center;margin-top:3rem" role="status">Yükleniyor…</p>';
    else if (A.screen === 'fatal') body = `<section class="card" style="max-width:560px;margin:2rem auto"><h2>Bir sorun oluştu</h2><p class="err">${esc(A.fatal)}</p><button class="btn" data-act="reload">Yeniden dene</button></section>`;
    else if (A.screen === 'auth') body = authView();
    else if (A.screen === 'student') body = studentShell();
    else if (A.screen === 'teacher') body = teacherShell();
    app.innerHTML = header() + `<main id="main">${body}</main>`;
    window.scrollTo(0, top ? 0 : y);
    if (fk) { const el = app.querySelector(`[data-fk="${fk}"]`); if (el && !el.disabled) el.focus({ preventScroll: true }); }
    if (T) T.rep = false;
  }

  /* ---------- Olaylar ---------- */
  app.addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b || b.disabled || !app.contains(b)) return;
    const a = b.dataset.act;
    try {
      if (a === 'signout') return signOut();
      if (a === 'reload') return location.reload();
      if (a === 'authtab') { A.authTab = b.dataset.t; A.authMsg = ''; A.form = { id: '', code: '' }; return render(); }
      if (a === 'primary') return A.authTab === 'signup' ? doSignup() : doLogin(A.authTab === 'teacher' ? 'teacher' : 'student');
      if (A.screen === 'student') return await studentAct(a, b);
      if (A.screen === 'teacher') return await teacherAct(a, b);
    } catch (err) { toast(errText(err)); }
  });
  app.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('#aId,#aPw,#aCode')) { e.preventDefault(); const p = app.querySelector('[data-act=primary]'); if (p && !p.disabled) p.click(); } });
  app.addEventListener('focusout', () => { if (T && T.rep) setTimeout(() => { const el = document.activeElement; if (!(el && el.matches && el.matches('input,textarea,select'))) render(); }, 50); });
  app.addEventListener('input', e => {
    if (e.target.id === 'aId') A.form.id = e.target.value; else if (e.target.id === 'aCode') A.form.code = e.target.value;
    const el = e.target.closest('[data-bind]'); if (!el || !S) return; const n = el.dataset.bind;
    if (n === 'note') { S.notes[S.date] = el.value.slice(0, 500); noteDate = S.date; clearTimeout(noteTimer); noteTimer = setTimeout(commitNote, 700); }
    else if (n.startsWith('f-') && S.form) S.form[n.slice(2)] = el.value;
  });
  app.addEventListener('change', e => {
    const el = e.target.closest('[data-bind]'); if (!el) return; const n = el.dataset.bind;
    if (S) {
      if (n === 'day-date' && isDate(el.value) && el.value <= todayS()) { commitNote(); S.date = el.value; S.form = null; render(); }
      else if (n === 'restore-file') restoreFile(el.files[0]);
      else if (n === 'f-kind' && S.form) S.form.kind = el.value;
    }
    if (T) {
      if (n === 't-class') { T.cid = el.value; T.sid = null; T.detail = false; render(); tRefresh(); tSubscribe(); }
      else if (n === 't-date' && isDate(el.value) && el.value <= todayS()) { T.date = el.value; render(); tRefresh(); }
      else if (n === 't-from' && isDate(el.value)) { T.range.from = el.value; if (T.range.to < el.value) T.range.to = el.value; if (spanDays(T.range.from, T.range.to) > 366) T.range.to = addDays(T.range.from, 365); render(); tRefresh(); }
      else if (n === 't-to' && isDate(el.value)) { T.range.to = el.value; if (T.range.from > el.value) T.range.from = el.value; if (spanDays(T.range.from, T.range.to) > 366) T.range.from = addDays(T.range.to, -365); render(); tRefresh(); }
      else if (n === 'join-open') {
        sb.from('classes').update({ join_open: el.checked }).eq('id', T.cid).then(({ error }) => { if (error) { toast(errText(error)); el.checked = !el.checked; } else { tClass().join_open = el.checked; toast(el.checked ? 'Yeni katılımlara açıldı.' : 'Yeni katılımlara kapatıldı.'); } });
      }
    }
  });

  boot();
})();
