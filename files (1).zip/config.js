// Supabase > Project Settings > API sayfasından alın.
// "anon / publishable" anahtar TARAYICIDA bulunmak üzere tasarlanmıştır; güvenlik RLS kurallarıyla sağlanır.
// ASLA "service_role" anahtarını buraya yazmayın.
window.IBADET_CONFIG = {
  SUPABASE_URL: 'BURAYA_PROJE_URL',          // örn. https://abcdxyz.supabase.co
  SUPABASE_ANON_KEY: 'BURAYA_ANON_ANAHTAR',
  // Öğrenciler e-posta yerine rumuzla giriş yapar; arka planda rumuz@ALAN_ADI e-postası üretilir.
  // Gerçek e-posta alınmaz ve bu adrese hiç e-posta gönderilmez (README Bölüm 3'ü okuyun).
  STUDENT_EMAIL_DOMAIN: 'ogrenci.ibadet-defterim.com'
};
