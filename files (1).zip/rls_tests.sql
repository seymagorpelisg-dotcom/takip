-- =====================================================================
-- Erişim kuralı (RLS) testleri — Supabase SQL Editor'de, schema.sql'den SONRA çalıştırın.
-- Her şey tek bir işlem içinde yapılır ve en sonda ROLLBACK ile geri alınır (veri kalmaz).
-- Bir test başarısız olursa hata mesajı hangi kuralın bozulduğunu söyler; hata yoksa
-- betik sonunda "TÜM TESTLER GEÇTİ" notu görünür.
-- NOT: Bu betiği yazan taraf (Claude) bir PostgreSQL ortamında ÇALIŞTIRAMADI. İlk çalıştırmada
-- fixture (auth.users ekleme) adımı projenizin sürümüne göre uyarlama gerektirebilir.
-- =====================================================================
begin;

-- ---- Fixture (postgres rolüyle) ----
insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-0000000000a1', 't1@test.local'),
  ('00000000-0000-0000-0000-0000000000a2', 't2@test.local'),
  ('00000000-0000-0000-0000-0000000000b1', 'ali@ogrenci.test'),
  ('00000000-0000-0000-0000-0000000000b2', 'veli@ogrenci.test'),
  ('00000000-0000-0000-0000-0000000000b3', 'can@ogrenci.test');

update public.profiles set role = 'teacher'
 where id in ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000a2');

insert into public.classes (id, teacher_id, name, join_code) values
  ('00000000-0000-0000-0000-00000000c001', '00000000-0000-0000-0000-0000000000a1', '6-A', 'KOD1234567'),
  ('00000000-0000-0000-0000-00000000c002', '00000000-0000-0000-0000-0000000000a2', '6-B', 'KOD7654321');

-- Ali: t1'in sınıfında ONAYLI. Veli: t1'in sınıfında ONAY BEKLİYOR. Can: t2'nin sınıfında onaylı.
insert into public.memberships (class_id, student_id, status) values
  ('00000000-0000-0000-0000-00000000c001', '00000000-0000-0000-0000-0000000000b1', 'active'),
  ('00000000-0000-0000-0000-00000000c001', '00000000-0000-0000-0000-0000000000b2', 'pending'),
  ('00000000-0000-0000-0000-00000000c002', '00000000-0000-0000-0000-0000000000b3', 'active');

insert into public.daily_logs (student_id, log_date, sabah) values
  ('00000000-0000-0000-0000-0000000000b1', current_date - 1, 'done'),
  ('00000000-0000-0000-0000-0000000000b2', current_date - 1, 'done'),
  ('00000000-0000-0000-0000-0000000000b3', current_date - 1, 'missed');
insert into public.quran_sessions (id, student_id, log_date, kind) values
  ('00000000-0000-0000-0000-0000000e0001', '00000000-0000-0000-0000-0000000000b1', current_date - 1, 'tilavet');
insert into public.private_notes (student_id, log_date, note) values
  ('00000000-0000-0000-0000-0000000000b1', current_date - 1, 'gizli not');

-- =============== ÖĞRENCİ ALİ olarak ===============
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}', true);

do $$ declare n int; begin
  select count(*) into n from public.daily_logs;
  assert n = 1, 'T1: öğrenci yalnızca kendi günlük kaydını görmeli (görülen: ' || n || ')';
  select count(*) into n from public.profiles;
  assert n = 1, 'T2: öğrenci başka profilleri görmemeli (görülen: ' || n || ')';
  select count(*) into n from public.classes;
  assert n = 0, 'T3: öğrenci sınıf tablosunu (katılım kodu!) okuyamamalı';
  select count(*) into n from public.private_notes;
  assert n = 1, 'T4: öğrenci kendi notunu görmeli';
end $$;

do $$ begin  -- T5: rol yükseltme
  begin update public.profiles set role = 'teacher' where id = auth.uid();
        raise exception 'T5 BAŞARISIZ: öğrenci kendini öğretmen yapabildi';
  exception when insufficient_privilege then null; end;
end $$;

do $$ declare n int; begin  -- T6: kendini onaylama (satır etkilenmemeli)
  update public.memberships set status = 'active' where student_id = auth.uid();
  get diagnostics n = row_count;
  assert n = 0, 'T6: öğrenci üyelik durumunu değiştirebildi';
end $$;

do $$ begin  -- T7: başkası adına kayıt
  begin insert into public.daily_logs (student_id, log_date, sabah)
        values ('00000000-0000-0000-0000-0000000000b3', current_date - 2, 'done');
        raise exception 'T7 BAŞARISIZ: başka öğrenci adına kayıt eklenebildi';
  exception when insufficient_privilege then null; end;
end $$;

do $$ declare n int; begin  -- T8: başkasının kaydını güncelleme/silme (0 satır etkilenmeli)
  update public.daily_logs set sabah = 'missed' where student_id = '00000000-0000-0000-0000-0000000000b3';
  get diagnostics n = row_count; assert n = 0, 'T8a: başkasının kaydı güncellenebildi';
  delete from public.daily_logs where student_id = '00000000-0000-0000-0000-0000000000b3';
  get diagnostics n = row_count; assert n = 0, 'T8b: başkasının kaydı silinebildi';
end $$;

do $$ begin  -- T9: gelecek tarih
  begin insert into public.daily_logs (student_id, log_date, sabah)
        values (auth.uid(), current_date + 3, 'done');
        raise exception 'T9 BAŞARISIZ: gelecek güne kayıt girilebildi';
  exception when sqlstate '22008' then null; end;
end $$;

do $$ declare n int; begin  -- T10: aynı kaydı iki kez gönderme (idempotent upsert)
  insert into public.daily_logs (student_id, log_date, ogle) values (auth.uid(), current_date - 3, 'done')
    on conflict (student_id, log_date) do update set ogle = excluded.ogle;
  insert into public.daily_logs (student_id, log_date, ogle) values (auth.uid(), current_date - 3, 'done')
    on conflict (student_id, log_date) do update set ogle = excluded.ogle;
  select count(*) into n from public.daily_logs where log_date = current_date - 3;
  assert n = 1, 'T10: mükerrer günlük kayıt oluştu';
  insert into public.quran_sessions (id, student_id, log_date) values ('00000000-0000-0000-0000-0000000e0002', auth.uid(), current_date - 3)
    on conflict (id) do update set log_date = excluded.log_date;
  insert into public.quran_sessions (id, student_id, log_date) values ('00000000-0000-0000-0000-0000000e0002', auth.uid(), current_date - 3)
    on conflict (id) do update set log_date = excluded.log_date;
  select count(*) into n from public.quran_sessions where id = '00000000-0000-0000-0000-0000000e0002';
  assert n = 1, 'T10b: mükerrer Kur''an oturumu oluştu';
end $$;

do $$ begin  -- T11: öğrenci sınıf oluşturamaz
  begin perform * from public.create_class('Sahte');
        raise exception 'T11 BAŞARISIZ: öğrenci sınıf oluşturabildi';
  exception when insufficient_privilege then null; end;
end $$;

do $$ begin  -- T12: zaten sınıfta olan öğrenci tekrar katılamaz; yanlış kod reddedilir
  begin perform * from public.join_class('YANLISKOD1'); raise exception 'T12a BAŞARISIZ';
  exception when raise_exception then
    if sqlerrm like 'T12a%' then raise; end if; end;
  begin perform * from public.join_class('KOD7654321'); raise exception 'T12b BAŞARISIZ';
  exception when raise_exception then
    if sqlerrm like 'T12b%' then raise; end if; end;
end $$;

reset role;

-- =============== ANON (girişsiz) ===============
set local role anon;
do $$ begin
  begin perform count(*) from public.daily_logs; raise exception 'T13 BAŞARISIZ: anon günlük kayıt okuyabildi';
  exception when insufficient_privilege then null; end;
  begin perform count(*) from public.profiles; raise exception 'T13b BAŞARISIZ: anon profil okuyabildi';
  exception when insufficient_privilege then null; end;
end $$;
reset role;

-- =============== ÖĞRETMEN 1 ===============
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);

do $$ begin
  assert (select count(*) from public.daily_logs where student_id = '00000000-0000-0000-0000-0000000000b1') >= 1,
    'T14: öğretmen onaylı öğrencinin (Ali) kaydını görmeli';
  assert (select count(*) from public.daily_logs where student_id = '00000000-0000-0000-0000-0000000000b2') = 0,
    'T15: öğretmen ONAY BEKLEYEN öğrencinin (Veli) kaydını görmemeli';
  assert (select count(*) from public.daily_logs where student_id = '00000000-0000-0000-0000-0000000000b3') = 0,
    'T16: öğretmen BAŞKA SINIFIN öğrencisinin (Can) kaydını görmemeli';
  assert (select count(*) from public.quran_sessions where student_id = '00000000-0000-0000-0000-0000000000b1') >= 1,
    'T17: öğretmen onaylı öğrencinin Kur''an oturumunu görmeli';
  assert (select count(*) from public.private_notes) = 0,
    'T18: öğretmen ÖZEL NOTLARI hiçbir koşulda görmemeli';
  assert (select count(*) from public.profiles where id = '00000000-0000-0000-0000-0000000000b2') = 1,
    'T19: öğretmen onay bekleyen öğrencinin rumuzunu görmeli (onaylamak için)';
  assert (select count(*) from public.profiles where id = '00000000-0000-0000-0000-0000000000b3') = 0,
    'T20: öğretmen başka sınıfın öğrencisinin profilini görmemeli';
  assert (select count(*) from public.classes) = 1, 'T21: öğretmen yalnızca kendi sınıfını görmeli';
end $$;

do $$ declare n int; begin  -- T22: öğretmen öğrenci kaydını DEĞİŞTİREMEZ
  begin update public.daily_logs set sabah = 'missed' where student_id = '00000000-0000-0000-0000-0000000000b1';
        get diagnostics n = row_count;
        if n > 0 then raise exception 'T22 BAŞARISIZ: öğretmen öğrenci kaydını değiştirebildi'; end if;
  exception when insufficient_privilege then null; end;
end $$;

do $$ declare n int; begin  -- T23: öğretmen kendi sınıfında öğrenciyi onaylayabilir, başkasınınkini onaylayamaz
  update public.memberships set status = 'active' where student_id = '00000000-0000-0000-0000-0000000000b2';
  get diagnostics n = row_count; assert n = 1, 'T23a: öğretmen kendi sınıfında onaylayamadı';
  update public.memberships set status = 'pending' where student_id = '00000000-0000-0000-0000-0000000000b3';
  get diagnostics n = row_count; assert n = 0, 'T23b: öğretmen başka sınıfta üyelik değiştirebildi';
  assert (select count(*) from public.daily_logs where student_id = '00000000-0000-0000-0000-0000000000b2') = 1,
    'T23c: onaydan sonra öğretmen Veli''nin kaydını görmeli';
end $$;

do $$ declare r record; begin  -- T24: öğretmen sınıf oluşturabilir, kod rastgele ve 10 haneli
  select * into r from public.create_class('Yeni Sınıf');
  assert char_length(r.out_join_code) = 10, 'T24: katılım kodu 10 haneli değil';
end $$;

do $$ begin  -- T25: başka öğretmenin sınıfında kod yenilenemez
  begin perform public.regenerate_join_code('00000000-0000-0000-0000-00000000c002');
        raise exception 'T25 BAŞARISIZ: başka öğretmenin sınıf kodu yenilenebildi';
  exception when insufficient_privilege then null; end;
end $$;

reset role;

-- =============== ÖĞRENCİ CAN: kodla katılma akışı ===============
-- (Can zaten t2'de; yeni bir öğrenciyle akışı sınayalım)
insert into auth.users (id, email) values ('00000000-0000-0000-0000-0000000000b4', 'deniz@ogrenci.test');
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b4","role":"authenticated"}', true);
do $$ declare r record; begin
  select * into r from public.join_class('kod1234567');  -- küçük harf de kabul
  assert r.out_status = 'pending', 'T26: kodla katılım "pending" başlamalı';
  assert (select count(*) from public.daily_logs) = 0, 'T27: onaysız öğrenci başkasının verisini görmemeli';
end $$;
reset role;

do $$ begin raise notice 'TÜM TESTLER GEÇTİ (varsa yukarıda hata görünmezse)'; end $$;
rollback;
