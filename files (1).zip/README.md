# İbadet Takip Defterim

Öğrencilerin namaz ve Kur’an kayıtlarını girdiği, öğretmenin kendi panelinden **canlı** takip ettiği çevrim içi uygulama.
Merkezi veri tabanı: **Supabase** (Auth + PostgreSQL + Row Level Security + Realtime). Ön yüz: derleme gerektirmeyen statik HTML/CSS/JS.

> **Dürüst durum özeti (önce bunu okuyun)**
> - Kod ve SQL **yazıldı**. Ben (Claude) bu ortamda **gerçek bir Supabase projesine bağlanamadım** ve PostgreSQL çalıştıramadım.
> - Bu yüzden **veri tabanı erişim kuralları (RLS) ve gerçek zamanlı senkronizasyon gerçek backend üzerinde test EDİLMEDİ.** İkisini sizin kurulumunuzda doğrulamanız gerekir (Bölüm 6). Bunun için hazır test betiği var: `supabase/rls_tests.sql`.
> - Arayüz mantığı, **sahte (taklit) bir Supabase istemcisiyle** tarayıcıda test edildi (41 kontrol geçti). Bu test güvenliği kanıtlamaz; yalnızca ekranların, kayıt kuyruğunun, hata durumlarının ve raporların çalıştığını gösterir.
> - Okulda gerçek çocuk verisiyle kullanmadan önce Bölüm 7’deki veri koruma/izin sürecini tamamlayın.

---

## 1. Mimari ve gerekçe

```
 Öğrenci tarayıcısı ─┐                         ┌─ Supabase Auth (giriş, oturum)
                     ├─ HTTPS ─ supabase-js ───┼─ PostgreSQL + RLS (yetkilendirme BURADA)
 Öğretmen tarayıcısı ┘   (yalnızca anon key)   └─ Realtime (değişiklik bildirimi)
        statik dosyalar: web/index.html, style.css, config.js, app.js
```

| Karar | Gerekçe |
|---|---|
| Supabase | İlişkisel veri tabanı, yerleşik kimlik doğrulama, **sunucu tarafında satır düzeyinde yetki (RLS)**, Realtime; kendi sunucunuzu işletmeniz gerekmez. |
| Statik ön yüz (framework yok) | Derleme aracı gerekmez; herhangi bir statik barındırmaya (Cloudflare Pages, Netlify, GitHub Pages…) konabilir; bakımı basit. |
| Yetkilendirme yalnızca RLS + RPC | Tarayıcıdaki `anon` anahtar herkese açıktır. Güvenlik, anahtarı gizlemekten değil, veri tabanı kurallarından gelir. Arayüzdeki “rol” kontrolleri yalnızca yönlendirmedir. |
| Realtime yalnızca “tetikleyici” | Olay geldiğinde arayüz olay içeriğine güvenmez; yetkili sorgularla verileri **yeniden çeker**. (Realtime silme olayları RLS ile filtrelenmez; bu yaklaşım bunu etkisiz kılar.) 45 sn’de bir yedek yenileme de vardır. |
| Alternatif | Supabase yerine Firebase (NoSQL) veya kendi sunucunuz da olurdu. İlişkisel model + RLS bu proje için daha uygun bulundu. Kendi sunucunuz en fazla kontrolü verir ama bakım/güvenlik yükü size geçer. |

**Maliyet:** Supabase’in ücretsiz katmanı küçük bir sınıf için yeterli olabilir; ancak **koşulları (veri/bant genişliği sınırları, hareketsizlikte projenin duraklatılması, yedekleme) değişebilir.** Kesin sınırları yayına almadan önce Supabase fiyatlandırma sayfasından doğrulayın. Bu belgede sınırsız kullanım veya sabit maliyet garantisi verilmez.

## 2. Dosya yapısı

```
ibadet-takip-defterim/
├─ README.md
├─ supabase/
│  ├─ schema.sql        tablolar, tetikleyiciler, RLS politikaları, RPC'ler, Realtime yayını
│  └─ rls_tests.sql     erişim kuralı testleri (Supabase SQL Editor'de çalıştırın)
├─ web/
│  ├─ index.html  style.css  app.js
│  └─ config.js         ← KENDİ proje URL'nizi ve anon anahtarınızı yazacağınız dosya
└─ tests/
   ├─ ui_test.py + fake-supabase.js   sahte backend ile arayüz testi (güvenlik testi DEĞİL)
```

## 3. Kurulum (sizin yapmanız gereken adımlar)

Hizmet hesabı/proje oluşturmak sizin sorumluluğunuzdadır; ben sizin adınıza bir şey oluşturmadım.

1. **Supabase hesabı ve projesi oluşturun** (supabase.com). Bölge olarak size yakın (örn. Frankfurt) seçin. Güçlü bir veri tabanı parolası belirleyin ve saklayın.
2. **SQL Editor → New query** → `supabase/schema.sql` içeriğinin tamamını yapıştırıp çalıştırın. Hata vermemeli.
3. **Authentication → Providers → Email**: **“Confirm email” seçeneğini KAPATIN.** Öğrenciler gerçek e-posta vermez; kapatılmazsa öğrenci kaydı çalışmaz.
4. **Authentication → Providers → Email → Minimum password length**: 6 (varsayılan) kalabilir. Daha uzun yaparsanız arayüzdeki “en az 6 karakter” uyarısını `web/app.js` içinde güncelleyin.
5. **Authentication → Rate Limits**: Bir okulun tek IP’den çok sayıda öğrenci kaydı/girişi sınıra takılabilir. Sınırları görüp gerekirse ayarlayın.
6. **Öğrenci e-posta alan adı (önemli, doğrulanmadı):** Öğrenciler rumuzla girer; arka planda `rumuz@<alan>` biçiminde sahte bir e-posta üretilir (`web/config.js` → `STUDENT_EMAIL_DOMAIN`). Bu adrese **hiçbir e-posta gönderilmez**. Bazı Supabase yapılandırmaları geçersiz/ölü alan adlarını reddedebilir. Bunu bilmediğim için: **kendi kontrolünüzdeki bir alan adı** (örn. `ogrenci.okulunuz.k12.tr`) kullanmanızı ve ilk öğrenci kaydını mutlaka denemenizi öneririm. Kayıt “e-posta geçersiz” diye reddedilirse alan adını değiştirin.
7. **Project Settings → API**: `Project URL` ve `anon public` anahtarı `web/config.js` içine yazın. **`service_role` anahtarını asla yazmayın.**
8. **Öğretmen hesabı** (Bölüm 4) oluşturun.
9. `supabase/rls_tests.sql` dosyasını çalıştırın (Bölüm 6).
10. `web/` klasörünü bir **HTTPS** statik barındırmaya yükleyin (Bölüm 5).

## 4. Öğretmen hesabı oluşturma

Öğretmen rolü uygulamadan **alınamaz** (herkes kendini öğretmen yapamasın diye). Yönetici (siz) verir:

1. Supabase → **Authentication → Users → Add user → Create new user**: öğretmenin e-postası ve parolası, **“Auto Confirm User” işaretli**.
2. **SQL Editor**’de çalıştırın:
   ```sql
   update public.profiles set role = 'teacher'
   where id = (select id from auth.users where email = 'ogretmen@okul.edu.tr');
   ```
3. Öğretmen uygulamada **Öğretmen** sekmesinden e-posta + parolayla girer, ilk sınıfını oluşturur ve üretilen **katılım kodunu** görür.

Kullanıcı kaydının `role` sütununu istemci güncelleyemez (sütun yetkisi yok); yeni kullanıcılar tetikleyiciyle her zaman `student` olur.

## 5. Yayına alma

`web/` klasörünün içeriğini (4 dosya) statik barındırmaya yükleyin (Cloudflare Pages, Netlify, GitHub Pages veya okulun kendi web sunucusu). **HTTPS şarttır** (oturum güvenliği için; ayrıca panoya kopyalama ve `crypto.randomUUID` güvenli bağlam ister). Giriş yönlendirme/e-posta bağlantısı kullanılmadığından Auth URL ayarlarında ek bir işlem gerekmez; yine de Supabase’de “Site URL”i yayın adresinize ayarlayın.

Öneriler: (a) `index.html` içindeki `supabase-js` betiği sabit sürümdür (2.45.4); yayına almadan önce bu betik için SRI (`integrity=`) ekleyebilir veya dosyayı kendi sunucunuza kopyalayabilirsiniz. (b) Barındırmada `Content-Security-Policy` başlığı ile yalnızca kendi alanınıza, `cdn.jsdelivr.net` ve `*.supabase.co` adresine izin verin.

## 6. Doğrulamanız gereken şeyler (benim yapamadıklarım)

| # | Doğrulama | Nasıl |
|---|---|---|
| 1 | **RLS/erişim kuralları** | `supabase/rls_tests.sql`’i SQL Editor’de çalıştırın. Her şey tek işlemde yapılıp geri alınır. Hata yoksa sonda “TÜM TESTLER GEÇTİ” notu çıkar. Betik, `auth.users`’a doğrudan satır ekler; projenizin sürümü buna izin vermezse fixture adımını uyarlamanız gerekebilir. **Ben bu betiği çalıştıramadım.** |
| 2 | **Gerçek zamanlı güncelleme** | İki tarayıcıda (biri öğretmen, biri öğrenci) giriş yapın; öğrenci bir vakit işaretlesin; öğretmen panelinin yenilemeden değiştiğini görün. Database → Replication’da `daily_logs`, `quran_sessions`, `memberships` tablolarının `supabase_realtime` yayınında olduğunu kontrol edin. |
| 3 | **Yetkisiz API erişimi** | Tarayıcı konsolunda (öğrenci oturumuyla) `supabase.from('daily_logs').select('*')` benzeri bir sorgu yalnızca kendi satırlarınızı döndürmeli; `private_notes` yalnızca kendi notlarınızı. Girişsizken (anon) tüm tablolar “permission denied” vermeli. |
| 4 | **Öğrenci kaydı** | Bölüm 3, madde 6’daki alan adı sorununu ilk kayıtta test edin. |
| 5 | **Gerçek cihazlar** | Birkaç gerçek telefon/tabletle kullanın (ekran görüntüleri yalnızca masaüstü Chromium’da alındı). |

## 7. Gizlilik ve veri güvenliği

**Kim neyi görür**
- Öğrenci: yalnızca kendi kayıtları. Başka öğrencinin adı, durumu, notu görünmez.
- Öğretmen: yalnızca **kendi sınıfındaki, onayladığı** öğrencilerin namaz durumları ve Kur’an oturumları. Onay bekleyen öğrencinin yalnızca rumuzunu görür.
- **Özel notları kimse göremez** (öğretmen dahil); ayrı tabloda, yalnızca sahibine politika vardır.
- Öğretmen kayıt **değiştiremez** (yalnızca okur). Düzeltme yetkisi eklenecekse, kimin değiştirdiğini kaydeden ayrı bir tasarım gerekir; v1’de yok.

**Toplanan veri:** rumuz, şifre (Supabase Auth’ta özetlenmiş), sınıf üyeliği, namaz/Kur’an kayıtları. Telefon, adres, doğum tarihi, gerçek e-posta **istenmez**. Rumuz için gerçek ad kullanmamaları önerilir (öğretmen, rumuz–öğrenci eşleştirmesini kendi listesinde tutabilir).

**Sınıf kodu ve katılım:** Kod tek başına erişim vermez. Kodu bilen biri yalnızca *kendi* hesabı için “onay bekliyor” isteği oluşturabilir (`join_class` RPC’si). Öğretmen onaylamadan hiçbir kayıt açılmaz. Kod sızarsa “Kodu yenile” veya “Yeni katılımlara kapat” kullanılır. Kod 10 haneli rastgeledir (~40 bit); ayrıca deneme sınırlaması yoktur (Auth rate limit giriş içindir, `join_class` için değil).

**Okul/veli süreçleri (zorunlu uyarı):** Bu veriler ibadet bilgisi içerir ve çocuklara aittir. Uygulamayı gerçek öğrencilerle kullanmadan önce okulun/kurumun **veri koruma (KVKK) ve veli izni** süreçlerini, ilgili mevzuat ve kurum politikasını değerlendirin. Bu belge hukuki tavsiye değildir.

**Hesap ve veri silme**
- Öğrenci “Tüm kayıtlarımı sil” ile kayıtlarını ve üyeliğini siler (`delete_my_data`).
- Öğrenci “Sınıftan ayrıl” ile öğretmenin erişimini keser; öğretmen “Sınıftan çıkar” ile aynısını yapar (kayıtlar silinmez, erişim kalkar).
- **Auth hesabının kendisini** (rumuz/şifre) yönetici siler: Supabase → Authentication → Users → Delete. Hesap silinince profil ve tüm kayıtlar `on delete cascade` ile silinir.

**Hesap kurtarma (v1 sınırlaması):** Öğrenci şifresini unutursa uygulamadan sıfırlayamaz (e-posta yok). Yönetici Supabase → Authentication → Users’tan şifreyi sıfırlar veya öğrenci yeni rumuzla hesap açar (eski kayıtlar eski hesapta kalır). Öğretmenin öğrenci şifresini sıfırlayabilmesi için sunucu tarafı bir fonksiyon (Edge Function + `service_role`) gerekir; **v1’e eklenmedi**, çünkü gizli anahtarı tarayıcıya koymadan güvenle yazılıp test edilmesi gerekir.

**Paylaşımlı cihazlar:** Aynı bilgisayarı kullanan öğrenciler çıkış yapmalıdır. Oturum tarayıcıda saklanır.

## 8. Yedekleme ve veri dışa aktarma

- **Öğrenci:** Hesabım → “Verilerimi indir” (JSON) ve “Yedekten geri yükle”. Geri yükleme yalnızca *kendi* hesabına yazar, doğrulama yapar ve aynı günlerin üzerine yazar.
- **Öğretmen:** Rapor → “CSV indir” (Excel için UTF-8 BOM’lu, `;` ayraçlı; formül enjeksiyonuna karşı korumalı). “Yazdır / PDF olarak kaydet” tarayıcının yazdırma penceresini açar; **uygulama sunucuda PDF üretmez.**
- **Tüm veri tabanı:** Supabase’in yedekleme seçenekleri plana göre değişir (doğrulayın). Elle yedek için Supabase CLI ile `supabase db dump` veya Dashboard’dan dışa aktarma kullanılabilir. Düzenli yedeği ve geri yükleme provasını yapın.

## 9. Davranış kuralları (uygulanan)

- Üç durum: **Kıldım / Kılmadım / Henüz işaretlemedim**. İlk açılışta hepsi boş; boş ≠ “kılmadım”. Raporlarda “kayıt yok” ile “kılmadım” kesin ayrıdır; ilerleme hesabı yalnızca **bugüne kadarki** günleri (gün × 5) kapsar ve eksik kayıt “başarısızlık” gibi gösterilmez.
- **Kaydetme:** Değişiklik önce kuyruğa girer; “Kaydedildi” yalnızca **sunucu başarılı yanıt verdikten sonra** görünür. Bağlantı yoksa “sunucuya GÖNDERİLMEDİ” uyarısı ve **Tekrar dene** çıkar; gönderilmemiş günde “bu cihazdaki görüntü sunucudakiyle aynı değildir” notu gösterilir. Gönderim idempotent (upsert) olduğundan tekrar denemede mükerrer kayıt oluşmaz. Gönderilmemiş değişiklik varken sekme kapatılırsa tarayıcı uyarır. **Çevrim dışı kalıcı kuyruk yoktur** (sayfa kapanırsa gönderilmemiş değişiklik kaybolur); bu ayrı bir özellik olarak eklenebilir.
- **Öğretmen paneli:** “Canlı bağlantı / bağlantı yok” göstergesi, “Son güncelleme” saati; bağlantı kopunca kırmızı bant: veriler eski olabilir.
- **Tarih:** Bugün/gelecek denetimi Türkiye saatine (Europe/Istanbul) göre; gelecek güne kayıt hem arayüzde hem veri tabanında (tetikleyici) engellenir. Hafta Pazartesi’de başlar.
- **Yarışma yok:** Sıralama, liderlik tablosu, utandırıcı uyarı yok; öğrenciler alfabetik listelenir.
- **Kur’an:** Bir günde birden çok oturum; her oturumun kendi kimliği vardır (üzerine yazma olmaz). Basit “Kur’an okudum” veya isteğe bağlı ayrıntı (tür, sure/cüz, sayfa, süre). Bir günde en fazla 20 oturum. *Sapma:* oturum başına ayrı not yok; günlük özel not tek ve ayrıdır.

## 10. Test durumu (spesifikasyon Bölüm 15’e karşı)

| Senaryo | Durum |
|---|---|
| Öğretmen/öğrenci girişi, sınıfa katılma (onaylı akış), namaz/Kur’an kaydı, yenilemede korunma, öğretmenin görmesi, değişikliğin panele yansıması, tekrar gönderimde mükerrer olmaması, bağlantı kesilince hata, yedek/geri yükleme, mobil taşma, Türkçe karakter, tarih/hafta | **Sahte backend ile arayüzde geçti** (`tests/ui_test.py`, 41 kontrol). Gerçek Supabase’te **denenmedi**. |
| Öğrencinin başkasını göremediği, öğretmenin başka sınıfı göremediği, yetkisiz API isteği, kişisel notların gizliliği, rol yükseltmenin engellenmesi | **SQL olarak yazıldı** (`rls_tests.sql`), **çalıştırılmadı.** Sahte backend testindeki benzer kontroller güvenliği kanıtlamaz. |
| Gerçek zamanlı abonelik | Kod yazıldı; yalnızca sahte olay yayınıyla denendi. **Gerçek Realtime denenmedi.** |
| Supabase’in kayıt aşamasında sahte e-posta alan adını kabul etmesi | **Bilinmiyor**, Bölüm 3-6’ya bakın. |
| Telefon/tablet gerçek cihazlar | Denenmedi (yalnızca 390 px Chromium görünümü). |
| PDF | Sunucuda üretilmez; yalnızca tarayıcı yazdırma. Yazdırma stili A4 yatay için hazırlandı; tarayıcının yazdırma çıktısı bu ortamda üretilip gözle kontrol edildi (kontroller gizleniyor, tablo sığıyor). Çok öğrencili/31 günlük raporlar denenmedi. |

## 11. Bilinen sınırlar

- Şifre sıfırlama/öğretmenin öğrenci hesabını yönetmesi yok (Bölüm 7).
- `join_class` için deneme sınırlaması yok; kodu yenilemek ve onay şartı korumadır.
- Çevrim dışı kalıcı kuyruk yok.
- Öğretmen veri penceresi seçili aralık + seçili tarihin haftasıdır; çok uzun aralıklarda (≤366 gün) sayfalama yapılır (Supabase’in 1000 satır sınırı için), ama çok büyük sınıflarda yükleme yavaşlayabilir.
- Bir öğrenci aynı anda tek sınıfta olabilir.
